import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const rankingSessionsTable = pgTable("ranking_sessions", {
  id: serial("id").primaryKey(),
  jobTitle: text("job_title").notNull(),
  jobDescription: text("job_description").notNull(),
  filters: text("filters"),
  totalCandidates: integer("total_candidates").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertRankingSessionSchema = createInsertSchema(rankingSessionsTable).omit({ id: true, createdAt: true });
export type InsertRankingSession = z.infer<typeof insertRankingSessionSchema>;
export type RankingSession = typeof rankingSessionsTable.$inferSelect;
