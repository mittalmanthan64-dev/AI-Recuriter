import { pgTable, text, serial, timestamp, real, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const candidatesTable = pgTable("candidates", {
  id: serial("id").primaryKey(),
  // Real dataset identifier
  candidateId: text("candidate_id").unique(),
  // Core profile
  name: text("name").notNull(),
  headline: text("headline"),
  summary: text("summary"),
  location: text("location"),
  country: text("country"),
  yearsExperience: real("years_experience"),
  currentTitle: text("current_title"),
  currentCompany: text("current_company"),
  currentCompanySize: text("current_company_size"),
  currentIndustry: text("current_industry"),
  // Nested rich data stored as JSONB
  careerHistory: jsonb("career_history"),   // [{company, title, start_date, end_date, duration_months, is_current, industry, company_size, description}]
  education: jsonb("education"),             // [{institution, degree, field_of_study, start_year, end_year, grade, tier}]
  skills: jsonb("skills"),                   // [{name, proficiency, endorsements, duration_months}]
  certifications: jsonb("certifications"),   // [{name, issuer, year}]
  languages: jsonb("languages"),             // [{language, proficiency}]
  redrobSignals: jsonb("redrob_signals"),    // full signals object
  // Flattened key signals for fast filtering and deterministic availability scoring
  openToWork: boolean("open_to_work"),
  noticePeriodDays: integer("notice_period_days"),
  expectedSalaryMin: real("expected_salary_min"),
  expectedSalaryMax: real("expected_salary_max"),
  preferredWorkMode: text("preferred_work_mode"),
  willingToRelocate: boolean("willing_to_relocate"),
  githubActivityScore: real("github_activity_score"),
  lastActiveDate: text("last_active_date"),
  recruiterResponseRate: real("recruiter_response_rate"),
  interviewCompletionRate: real("interview_completion_rate"),
  offerAcceptanceRate: real("offer_acceptance_rate"),
  profileCompletenessScore: real("profile_completeness_score"),
  avgResponseTimeHours: real("avg_response_time_hours"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertCandidateSchema = createInsertSchema(candidatesTable).omit({ id: true, createdAt: true });
export type InsertCandidate = z.infer<typeof insertCandidateSchema>;
export type Candidate = typeof candidatesTable.$inferSelect;
