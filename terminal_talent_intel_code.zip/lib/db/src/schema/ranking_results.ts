import { pgTable, text, serial, timestamp, integer, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { rankingSessionsTable } from "./ranking_sessions";
import { candidatesTable } from "./candidates";

export const rankingResultsTable = pgTable("ranking_results", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull().references(() => rankingSessionsTable.id),
  candidateId: integer("candidate_id").notNull().references(() => candidatesTable.id),
  rank: integer("rank").notNull(),
  overallScore: real("overall_score").notNull(),
  skillsScore: real("skills_score"),
  experienceScore: real("experience_score"),
  cultureFitScore: real("culture_fit_score"),
  activityScore: real("activity_score"),
  reasoning: text("reasoning"),
  strengths: text("strengths").array(),
  gaps: text("gaps").array(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertRankingResultSchema = createInsertSchema(rankingResultsTable).omit({ id: true, createdAt: true });
export type InsertRankingResult = z.infer<typeof insertRankingResultSchema>;
export type RankingResult = typeof rankingResultsTable.$inferSelect;
