# Terminal Talent Intel

AI-powered candidate ranking system built for the **Redrob Hackathon — India Runs Data & AI Challenge**. Ranks the top 100 candidates from a 100,000-candidate pool for a Senior AI Engineer role. This Replit serves as the required **sandbox link** for the hackathon submission.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

### Hackathon submission commands

```bash
# Generate submission CSV (all 100k, ~24 seconds, CPU-only):
python3 scripts/rank_candidates.py --candidates artifacts/api-server/data/candidates.jsonl --out team_submission.csv

# Validate before uploading:
python3 scripts/validate_submission.py team_submission.csv

# Demo on 50-candidate sample:
python3 scripts/rank_candidates.py --sample --out demo_submission.csv
```

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

| Path | Purpose |
|---|---|
| `lib/db/src/schema/` | DB schema (candidates, ranking sessions) |
| `lib/api-spec/openapi.yaml` | OpenAPI spec (source of truth for API contract) |
| `artifacts/api-server/src/lib/submission-ranker.ts` | CPU-only TypeScript ranker (no API calls) |
| `scripts/rank_candidates.py` | Standalone Python ranker for submission generation |
| `scripts/validate_submission.py` | Official submission validator |
| `artifacts/api-server/data/candidates.jsonl` | Full 100k candidate pool (465 MB) |
| `artifacts/api-server/data/candidates.json` | 300-candidate subset (for DB seed + UI demo) |
| `team_submission.csv` | **Final submission CSV** (top 100, validated) |

## Architecture decisions

- **Career function scoring is primary (40%)** — parses role titles + job descriptions to determine what candidates actually did at work. Keyword stuffers (e.g. HR Managers with Python in their skills list) score low.
- **Skills depth = proficiency × duration × endorsements** — expert skill with 0 months duration is a honeypot/inflation signal, weighted near-zero.
- **Availability as a multiplier** — applied post-scoring so engagement signals don't override qualification signals, but they can still gate great candidates.
- **CPU-only ranker** — no OpenAI/Anthropic calls during ranking; full 100k processed in ~24s on CPU, well within the 5-minute limit.
- **Honeypot detection** — three complementary traps: expert skills with 0-month duration, all-expert skill profiles, and career history duration vs. claimed YoE mismatch.

## Product

- **Dashboard** — stats on the seeded candidate pool (300 candidates from real JSONL data)
- **Rank Candidates** — GPT-4o-mini powered interactive ranker (for demo/exploration — uses OpenAI, NOT for submission)
- **Candidate Pool** — browse all seeded candidates with proficiency-colored skill pills, redrob signals, career timeline
- **Hackathon Submit** — generate the challenge submission CSV on demand via CPU-only ranker (demo mode: 50 candidates instantly; full mode: 100k in ~2 min via API)

## Ranker scoring weights

| Component | Weight | Anti-abuse purpose |
|---|---|---|
| Career Function | 40% | Kills keyword stuffers — what you did > what you list |
| Skills Depth | 25% | proficiency × duration × endorsements for retrieval/ML skills |
| Experience Fit | 15% | JD wants 5–9 years; soft bands |
| Education | 10% | Tier 1/CS bonus, not hard filter |
| Activity Signals | 10% | GitHub score + completeness + relevant certs |
| Availability | ×0.12–1.0 | Post-score: recency, open_to_work, response rate |

## User preferences

- Keep the dark terminal aesthetic consistent across all pages
- Submission CSV filename: `team_submission.csv`

## Gotchas

- `__dirname` in compiled API routes resolves to `dist/`, so data path is `path.join(__dirname, "..", "data", ...)` (one level up, not two)
- The 465MB `candidates.jsonl` is on disk but gitignored — must be present for full submission generation
- Python ranker sorts by `(-score, candidate_id)` **after rounding** to satisfy spec §3 tie-break requirement

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
- Challenge submission spec: `submission_spec.docx` in the hackathon bundle
- Official validator: `scripts/validate_submission.py`
