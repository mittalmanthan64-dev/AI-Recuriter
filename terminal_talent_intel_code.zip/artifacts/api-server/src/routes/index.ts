import { Router, type IRouter } from "express";
import healthRouter from "./health";
import candidatesRouter from "./candidates";
import rankingRouter from "./ranking";
import statsRouter from "./stats";
import submissionRouter from "./submission";

const router: IRouter = Router();

router.use(healthRouter);
router.use(candidatesRouter);
router.use(rankingRouter);
router.use(statsRouter);
router.use(submissionRouter);

export default router;
