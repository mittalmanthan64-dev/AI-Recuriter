import { Router, type IRouter } from "express";
import * as path from "path";
import * as fs from "fs";
import { generateSubmission, rowsToCsv, scoreCandidate, type RawCandidate } from "../lib/submission-ranker";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const JSONL_PATH = path.join(__dirname, "..", "data", "candidates.jsonl");
const SAMPLE_PATH = path.join(__dirname, "..", "data", "candidates.json");

router.get("/submission/status", (req, res) => {
  const hasFullDataset = fs.existsSync(JSONL_PATH);
  const hasSampleDataset = fs.existsSync(SAMPLE_PATH);

  let candidateCount = 0;
  if (hasFullDataset) {
    const stats = fs.statSync(JSONL_PATH);
    candidateCount = 100000; // known from dataset
  } else if (hasSampleDataset) {
    try {
      const sample = JSON.parse(fs.readFileSync(SAMPLE_PATH, "utf8")) as unknown[];
      candidateCount = sample.length;
    } catch {}
  }

  res.json({
    hasFullDataset,
    hasSampleDataset,
    candidateCount,
    datasetPath: hasFullDataset ? JSONL_PATH : SAMPLE_PATH,
    ready: hasFullDataset || hasSampleDataset,
  });
});

router.post("/submission/generate", async (req, res): Promise<void> => {
  const { sampleOnly = false } = req.body as { sampleOnly?: boolean };

  req.log.info({ sampleOnly }, "Generating submission CSV");

  try {
    if (sampleOnly || !fs.existsSync(JSONL_PATH)) {
      // Fast path: use sample JSON (50 candidates)
      if (!fs.existsSync(SAMPLE_PATH)) {
        res.status(400).json({ error: "No candidate data available." });
        return;
      }

      const raw: RawCandidate[] = JSON.parse(fs.readFileSync(SAMPLE_PATH, "utf8")) as RawCandidate[];
      const scored = raw.map(scoreCandidate).sort((a, b) => {
        if (b.score !== a.score) return b.score - a.score;
        return a.candidateId.localeCompare(b.candidateId);
      });

      const top = scored.slice(0, Math.min(50, scored.length));
      const rows = top.map((s, i) => ({
        candidate_id: s.candidateId,
        rank: i + 1,
        score: Math.round(Math.min(0.9999, Math.max(0.0001, s.score)) * 10000) / 10000,
        reasoning: s.reasoning || `${s.raw.profile.current_title} with ${s.raw.profile.years_of_experience}y exp; career score ${s.careerScore.toFixed(0)}/100; skills score ${s.skillsScore.toFixed(0)}/100.`,
      }));

      // Ensure non-increasing scores
      for (let i = 1; i < rows.length; i++) {
        if (rows[i].score > rows[i - 1].score) rows[i].score = rows[i - 1].score;
      }

      const csv = rowsToCsv(rows);
      const stats = {
        totalProcessed: raw.length,
        honeypotCount: scored.filter((s) => s.isHoneypot).length,
        topCandidate: top[0]
          ? { id: top[0].candidateId, score: top[0].score, careerScore: top[0].careerScore }
          : null,
      };

      res.json({ csv, rows, stats, mode: "sample" });
      return;
    }

    // Full path: stream all 100k candidates
    const startTime = Date.now();
    let processed = 0;

    const rows = await generateSubmission({
      jsonlPath: JSONL_PATH,
      topN: 100,
      onProgress: (n) => {
        processed = n;
        req.log.info({ processed, elapsed: Date.now() - startTime }, "Ranking progress");
      },
    });

    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
    req.log.info({ elapsed, topScore: rows[0]?.score }, "Submission generated");

    const csv = rowsToCsv(rows);
    res.json({
      csv,
      rows: rows.slice(0, 10), // first 10 for preview
      stats: {
        totalProcessed: 100000,
        elapsed: parseFloat(elapsed),
        topCandidate: rows[0] ? { id: rows[0].candidate_id, score: rows[0].score } : null,
      },
      mode: "full",
    });
  } catch (err) {
    req.log.error({ err }, "Submission generation failed");
    res.status(500).json({ error: "Failed to generate submission." });
  }
});

export default router;
