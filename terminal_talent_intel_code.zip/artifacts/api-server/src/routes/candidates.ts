import { Router, type IRouter } from "express";
import { db, candidatesTable } from "@workspace/db";
import { GetCandidateParams } from "@workspace/api-zod";
import { eq, gte, sql, and } from "drizzle-orm";

const router: IRouter = Router();

router.get("/candidates", async (req, res): Promise<void> => {
  const { minExperience, location, skills } = req.query as Record<string, string | undefined>;

  const conditions = [];

  if (minExperience) {
    conditions.push(gte(candidatesTable.yearsExperience, parseFloat(minExperience)));
  }
  if (location) {
    conditions.push(sql`lower(${candidatesTable.location}) like lower(${"%" + location + "%"})`);
  }
  if (skills) {
    const skillList = skills.split(",").map((s) => s.trim().toLowerCase());
    for (const skill of skillList) {
      // skills is now JSONB array of {name, proficiency, ...}
      conditions.push(
        sql`exists (
          select 1 from jsonb_array_elements(${candidatesTable.skills}) as sk
          where lower(sk->>'name') like lower(${`%${skill}%`})
        )`
      );
    }
  }

  const candidates =
    conditions.length > 0
      ? await db.select().from(candidatesTable).where(and(...conditions)).orderBy(candidatesTable.name)
      : await db.select().from(candidatesTable).orderBy(candidatesTable.name);

  res.json(
    candidates.map((c) => ({
      id: c.id,
      candidateId: c.candidateId,
      name: c.name,
      headline: c.headline,
      summary: c.summary,
      location: c.location,
      country: c.country,
      currentTitle: c.currentTitle,
      currentCompany: c.currentCompany,
      currentCompanySize: c.currentCompanySize,
      currentIndustry: c.currentIndustry,
      yearsExperience: c.yearsExperience,
      skills: c.skills,
      education: c.education,
      careerHistory: c.careerHistory,
      certifications: c.certifications,
      languages: c.languages,
      openToWork: c.openToWork,
      noticePeriodDays: c.noticePeriodDays,
      expectedSalaryMin: c.expectedSalaryMin,
      expectedSalaryMax: c.expectedSalaryMax,
      preferredWorkMode: c.preferredWorkMode,
      willingToRelocate: c.willingToRelocate,
      githubActivityScore: c.githubActivityScore,
      recruiterResponseRate: c.recruiterResponseRate,
      interviewCompletionRate: c.interviewCompletionRate,
      lastActiveDate: c.lastActiveDate,
    }))
  );
});

router.get("/candidates/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = GetCandidateParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [c] = await db.select().from(candidatesTable).where(eq(candidatesTable.id, params.data.id));
  if (!c) {
    res.status(404).json({ error: "Candidate not found" });
    return;
  }

  res.json({
    id: c.id,
    candidateId: c.candidateId,
    name: c.name,
    headline: c.headline,
    summary: c.summary,
    location: c.location,
    country: c.country,
    currentTitle: c.currentTitle,
    currentCompany: c.currentCompany,
    currentCompanySize: c.currentCompanySize,
    currentIndustry: c.currentIndustry,
    yearsExperience: c.yearsExperience,
    skills: c.skills,
    education: c.education,
    careerHistory: c.careerHistory,
    certifications: c.certifications,
    languages: c.languages,
    openToWork: c.openToWork,
    noticePeriodDays: c.noticePeriodDays,
    expectedSalaryMin: c.expectedSalaryMin,
    expectedSalaryMax: c.expectedSalaryMax,
    preferredWorkMode: c.preferredWorkMode,
    willingToRelocate: c.willingToRelocate,
    githubActivityScore: c.githubActivityScore,
    recruiterResponseRate: c.recruiterResponseRate,
    interviewCompletionRate: c.interviewCompletionRate,
    offerAcceptanceRate: c.offerAcceptanceRate,
    lastActiveDate: c.lastActiveDate,
    redrobSignals: c.redrobSignals,
  });
});

export default router;
