import { Router, type IRouter } from "express";
import { db, candidatesTable, rankingSessionsTable } from "@workspace/db";
import { sql, count } from "drizzle-orm";

const router: IRouter = Router();

router.get("/stats/overview", async (req, res): Promise<void> => {
  const [totalCandidatesRow] = await db
    .select({ count: count() })
    .from(candidatesTable);

  const [totalSessionsRow] = await db
    .select({ count: count() })
    .from(rankingSessionsTable);

  const [avgExpRow] = await db
    .select({ avg: sql<number>`avg(${candidatesTable.yearsExperience})` })
    .from(candidatesTable);

  // Top skills from JSONB array
  const topSkillsResult = await db.execute(sql`
    SELECT sk->>'name' as skill_name, COUNT(*) as cnt
    FROM candidates, jsonb_array_elements(skills) as sk
    WHERE skills IS NOT NULL AND jsonb_typeof(skills) = 'array'
    GROUP BY sk->>'name'
    ORDER BY cnt DESC
    LIMIT 15
  `);
  const topSkills = (topSkillsResult.rows as Array<{ skill_name: string }>).map((r) => r.skill_name);

  // Work mode distribution
  const workModeResult = await db.execute(sql`
    SELECT preferred_work_mode, COUNT(*) as cnt
    FROM candidates
    WHERE preferred_work_mode IS NOT NULL
    GROUP BY preferred_work_mode
    ORDER BY cnt DESC
  `);

  // Open to work count
  const openToWorkResult = await db.execute(sql`
    SELECT COUNT(*) as cnt FROM candidates WHERE open_to_work = true
  `);
  const openToWorkRow = openToWorkResult.rows[0];

  // Industry distribution
  const industryResult = await db.execute(sql`
    SELECT current_industry, COUNT(*) as cnt
    FROM candidates
    WHERE current_industry IS NOT NULL
    GROUP BY current_industry
    ORDER BY cnt DESC
    LIMIT 8
  `);

  res.json({
    totalCandidates: Number(totalCandidatesRow.count),
    totalSessions: Number(totalSessionsRow.count),
    avgExperience: avgExpRow.avg ? Math.round(Number(avgExpRow.avg) * 10) / 10 : null,
    topSkills,
    workModeDistribution: (workModeResult.rows as Array<{ preferred_work_mode: string; cnt: string }>)
      .map((r) => ({ label: r.preferred_work_mode, count: Number(r.cnt) })),
    openToWorkCount: Number((openToWorkRow as any).cnt ?? 0),
    industryDistribution: (industryResult.rows as Array<{ current_industry: string; cnt: string }>)
      .map((r) => ({ label: r.current_industry, count: Number(r.cnt) })),
  });
});

export default router;
