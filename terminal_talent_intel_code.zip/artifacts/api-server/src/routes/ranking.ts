import { Router, type IRouter } from "express";
import { db, candidatesTable, rankingSessionsTable, rankingResultsTable } from "@workspace/db";
import { RunRankingBody, GetRankingSessionParams, ExportRankingSessionParams } from "@workspace/api-zod";
import { eq, desc } from "drizzle-orm";
import { rankCandidates } from "../lib/ranker";
import { logger } from "../lib/logger";

const router: IRouter = Router();

function candidatePublicFields(c: typeof candidatesTable.$inferSelect) {
  return {
    id: c.id,
    candidateId: c.candidateId,
    name: c.name,
    headline: c.headline,
    currentTitle: c.currentTitle,
    currentCompany: c.currentCompany,
    currentCompanySize: c.currentCompanySize,
    currentIndustry: c.currentIndustry,
    location: c.location,
    country: c.country,
    yearsExperience: c.yearsExperience,
    skills: c.skills,
    education: c.education,
    careerHistory: c.careerHistory,
    certifications: c.certifications,
    openToWork: c.openToWork,
    noticePeriodDays: c.noticePeriodDays,
    expectedSalaryMin: c.expectedSalaryMin,
    expectedSalaryMax: c.expectedSalaryMax,
    preferredWorkMode: c.preferredWorkMode,
    willingToRelocate: c.willingToRelocate,
    githubActivityScore: c.githubActivityScore,
    recruiterResponseRate: c.recruiterResponseRate,
    interviewCompletionRate: c.interviewCompletionRate,
    lastActiveDate: c.lastActiveDate,
  };
}

router.post("/ranking/run", async (req, res): Promise<void> => {
  const parsed = RunRankingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { jobDescription, jobTitle, filters } = parsed.data;
  const resolvedJobTitle = jobTitle ?? "Untitled Role";

  const candidates = await db.select().from(candidatesTable);
  if (candidates.length === 0) {
    res.status(400).json({ error: "No candidates in database." });
    return;
  }

  req.log.info({ jobTitle: resolvedJobTitle, candidateCount: candidates.length }, "Starting AI ranking");

  const rankedScores = await rankCandidates(candidates, jobDescription, resolvedJobTitle, {
    minExperience: filters?.minExperience ?? undefined,
    maxExperience: filters?.maxExperience ?? undefined,
    requiredSkills: filters?.requiredSkills ?? undefined,
    location: filters?.location ?? undefined,
    educationLevel: filters?.educationLevel ?? undefined,
  });

  const [session] = await db
    .insert(rankingSessionsTable)
    .values({
      jobTitle: resolvedJobTitle,
      jobDescription,
      filters: filters ? JSON.stringify(filters) : null,
      totalCandidates: rankedScores.length,
    })
    .returning();

  if (rankedScores.length > 0) {
    await db.insert(rankingResultsTable).values(
      rankedScores.map((score, idx) => ({
        sessionId: session.id,
        candidateId: score.candidateId,
        rank: idx + 1,
        overallScore: score.overallScore,
        skillsScore: score.skillsScore,
        experienceScore: score.experienceScore,
        cultureFitScore: score.cultureFitScore,
        activityScore: score.activityScore,
        reasoning: score.reasoning,
        strengths: score.strengths,
        gaps: score.gaps,
      }))
    );
  }

  const candidateMap = new Map(candidates.map((c) => [c.id, c]));

  const rankedCandidates = rankedScores.map((score, idx) => {
    const c = candidateMap.get(score.candidateId);
    return {
      ...candidatePublicFields(c!),
      candidateId: score.candidateId,
      name: score.name,
      overallScore: score.overallScore,
      rank: idx + 1,
      skillsScore: score.skillsScore,
      experienceScore: score.experienceScore,
      cultureFitScore: score.cultureFitScore,
      activityScore: score.activityScore,
      availabilityPenalty: score.availabilityPenalty,
      reasoning: score.reasoning,
      strengths: score.strengths,
      gaps: score.gaps,
    };
  });

  res.json({ sessionId: session.id, rankedCandidates, totalEvaluated: rankedScores.length, jobTitle: resolvedJobTitle });
});

router.get("/ranking/sessions", async (req, res): Promise<void> => {
  const sessions = await db
    .select()
    .from(rankingSessionsTable)
    .orderBy(desc(rankingSessionsTable.createdAt));

  res.json(sessions.map((s) => ({
    id: s.id,
    jobTitle: s.jobTitle,
    jobDescription: s.jobDescription,
    createdAt: s.createdAt.toISOString(),
    totalCandidates: s.totalCandidates,
  })));
});

router.get("/ranking/sessions/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = GetRankingSessionParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [session] = await db.select().from(rankingSessionsTable).where(eq(rankingSessionsTable.id, params.data.id));
  if (!session) { res.status(404).json({ error: "Session not found" }); return; }

  const results = await db
    .select()
    .from(rankingResultsTable)
    .where(eq(rankingResultsTable.sessionId, params.data.id))
    .orderBy(rankingResultsTable.rank);

  const candidateIds = results.map((r) => r.candidateId);
  const allCandidates = candidateIds.length > 0 ? await db.select().from(candidatesTable) : [];
  const candidateMap = new Map(allCandidates.map((c) => [c.id, c]));

  const rankedCandidates = results.map((r) => {
    const c = candidateMap.get(r.candidateId);
    return {
      ...(c ? candidatePublicFields(c) : {}),
      candidateId: r.candidateId,
      name: c?.name ?? "Unknown",
      overallScore: r.overallScore,
      rank: r.rank,
      skillsScore: r.skillsScore,
      experienceScore: r.experienceScore,
      cultureFitScore: r.cultureFitScore,
      activityScore: r.activityScore,
      reasoning: r.reasoning,
      strengths: r.strengths ?? [],
      gaps: r.gaps ?? [],
    };
  });

  res.json({ id: session.id, jobTitle: session.jobTitle, jobDescription: session.jobDescription, createdAt: session.createdAt.toISOString(), rankedCandidates });
});

router.get("/ranking/sessions/:id/export", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = ExportRankingSessionParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [session] = await db.select().from(rankingSessionsTable).where(eq(rankingSessionsTable.id, params.data.id));
  if (!session) { res.status(404).json({ error: "Session not found" }); return; }

  const results = await db
    .select()
    .from(rankingResultsTable)
    .where(eq(rankingResultsTable.sessionId, params.data.id))
    .orderBy(rankingResultsTable.rank);

  const allCandidates = await db.select().from(candidatesTable);
  const candidateMap = new Map(allCandidates.map((c) => [c.id, c]));

  const esc = (val: unknown) => {
    if (val == null) return "";
    const s = String(val);
    return s.includes(",") || s.includes('"') || s.includes("\n") ? `"${s.replace(/"/g, '""')}"` : s;
  };

  const headers = [
    "Rank", "Candidate ID", "Name", "Overall Score", "Skills Score", "Experience Score",
    "Culture Fit", "Activity Score", "Current Title", "Company", "Industry",
    "Location", "Country", "Years Experience",
    "Open to Work", "Notice Period (days)", "Expected Salary (LPA min)", "Expected Salary (LPA max)",
    "Work Mode", "Willing to Relocate", "GitHub Score",
    "Recruiter Response Rate", "Interview Completion Rate",
    "Top Skills", "Reasoning", "Strengths", "Gaps"
  ];

  const rows = results.map((r) => {
    const c = candidateMap.get(r.candidateId);
    const skills = (c?.skills as Array<{ name: string; proficiency: string }> | null) ?? [];
    const topSkills = skills
      .filter(s => s.proficiency === "expert" || s.proficiency === "advanced")
      .slice(0, 5)
      .map(s => `${s.name} (${s.proficiency})`)
      .join("; ");

    return [
      r.rank,
      esc(c?.candidateId),
      esc(c?.name),
      r.overallScore.toFixed(1),
      r.skillsScore?.toFixed(1) ?? "",
      r.experienceScore?.toFixed(1) ?? "",
      r.cultureFitScore?.toFixed(1) ?? "",
      r.activityScore?.toFixed(1) ?? "",
      esc(c?.currentTitle),
      esc(c?.currentCompany),
      esc(c?.currentIndustry),
      esc(c?.location),
      esc(c?.country),
      c?.yearsExperience ?? "",
      c?.openToWork ? "Yes" : "No",
      c?.noticePeriodDays ?? "",
      c?.expectedSalaryMin ?? "",
      c?.expectedSalaryMax ?? "",
      esc(c?.preferredWorkMode),
      c?.willingToRelocate ? "Yes" : "No",
      c?.githubActivityScore?.toFixed(1) ?? "N/A",
      c?.recruiterResponseRate != null ? `${Math.round(c.recruiterResponseRate * 100)}%` : "",
      c?.interviewCompletionRate != null ? `${Math.round(c.interviewCompletionRate * 100)}%` : "",
      esc(topSkills),
      esc(r.reasoning),
      esc((r.strengths ?? []).join("; ")),
      esc((r.gaps ?? []).join("; ")),
    ].join(",");
  });

  const csv = [headers.join(","), ...rows].join("\n");
  const filename = `ranked_${session.jobTitle.replace(/[^a-z0-9]/gi, "_").toLowerCase()}_${session.id}.csv`;
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  res.send(csv);
});

export default router;
