import { db, candidatesTable } from "@workspace/db";
import { count } from "drizzle-orm";
import { logger } from "./logger";
import * as fs from "fs";
import * as path from "path";

interface RawCandidate {
  candidate_id: string;
  profile: {
    anonymized_name: string;
    headline: string;
    summary: string;
    location: string;
    country: string;
    years_of_experience: number;
    current_title: string;
    current_company: string;
    current_company_size: string;
    current_industry: string;
  };
  career_history: Array<{
    company: string;
    title: string;
    start_date: string;
    end_date: string | null;
    duration_months: number;
    is_current: boolean;
    industry: string;
    company_size: string;
    description: string;
  }>;
  education: Array<{
    institution: string;
    degree: string;
    field_of_study: string;
    start_year: number;
    end_year: number;
    grade: string | null;
    tier: string;
  }>;
  skills: Array<{
    name: string;
    proficiency: string;
    endorsements: number;
    duration_months: number;
  }>;
  certifications: Array<{ name: string; issuer: string; year: number }>;
  languages: Array<{ language: string; proficiency: string }>;
  redrob_signals: {
    profile_completeness_score: number;
    signup_date: string;
    last_active_date: string;
    open_to_work_flag: boolean;
    recruiter_response_rate: number;
    avg_response_time_hours: number;
    notice_period_days: number;
    expected_salary_range_inr_lpa: { min: number; max: number };
    preferred_work_mode: string;
    willing_to_relocate: boolean;
    github_activity_score: number;
    interview_completion_rate: number;
    offer_acceptance_rate: number;
    [key: string]: unknown;
  };
}

function mapCandidate(raw: RawCandidate) {
  const s = raw.redrob_signals;
  return {
    candidateId: raw.candidate_id,
    name: raw.profile.anonymized_name,
    headline: raw.profile.headline,
    summary: raw.profile.summary,
    location: raw.profile.location,
    country: raw.profile.country,
    yearsExperience: raw.profile.years_of_experience,
    currentTitle: raw.profile.current_title,
    currentCompany: raw.profile.current_company,
    currentCompanySize: raw.profile.current_company_size,
    currentIndustry: raw.profile.current_industry,
    careerHistory: raw.career_history as unknown as Record<string, unknown>[],
    education: raw.education as unknown as Record<string, unknown>[],
    skills: raw.skills as unknown as Record<string, unknown>[],
    certifications: raw.certifications as unknown as Record<string, unknown>[],
    languages: raw.languages as unknown as Record<string, unknown>[],
    redrobSignals: s as unknown as Record<string, unknown>,
    // Flattened signals
    openToWork: s.open_to_work_flag,
    noticePeriodDays: s.notice_period_days,
    expectedSalaryMin: s.expected_salary_range_inr_lpa?.min ?? null,
    expectedSalaryMax: s.expected_salary_range_inr_lpa?.max ?? null,
    preferredWorkMode: s.preferred_work_mode,
    willingToRelocate: s.willing_to_relocate,
    githubActivityScore: s.github_activity_score >= 0 ? s.github_activity_score : null,
    lastActiveDate: s.last_active_date,
    recruiterResponseRate: s.recruiter_response_rate,
    interviewCompletionRate: s.interview_completion_rate,
    offerAcceptanceRate: s.offer_acceptance_rate >= 0 ? s.offer_acceptance_rate : null,
    profileCompletenessScore: s.profile_completeness_score,
    avgResponseTimeHours: s.avg_response_time_hours,
  };
}

export async function seedCandidatesIfEmpty(): Promise<void> {
  const [{ count: existingCount }] = await db
    .select({ count: count() })
    .from(candidatesTable);

  if (existingCount > 0) {
    logger.info({ count: existingCount }, "Candidates already seeded, skipping");
    return;
  }

  const dataPath = path.join(__dirname, "..", "data", "candidates.json");
  if (!fs.existsSync(dataPath)) {
    logger.warn({ dataPath }, "No candidates.json found, skipping seed");
    return;
  }

  logger.info({ dataPath }, "Loading candidates from dataset...");
  const raw: RawCandidate[] = JSON.parse(fs.readFileSync(dataPath, "utf8"));

  const mapped = raw.map(mapCandidate);

  // Insert in batches of 50 to avoid parameter limits
  const BATCH = 50;
  for (let i = 0; i < mapped.length; i += BATCH) {
    await db.insert(candidatesTable).values(mapped.slice(i, i + BATCH));
  }

  logger.info({ count: mapped.length }, "Seeded candidates from real dataset");
}
