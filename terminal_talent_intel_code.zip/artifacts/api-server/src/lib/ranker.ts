import { openai } from "./openai";
import type { Candidate } from "@workspace/db";
import { logger } from "./logger";

export interface RankingFilters {
  minExperience?: number | null;
  maxExperience?: number | null;
  requiredSkills?: string[];
  location?: string | null;
  educationLevel?: string | null;
}

export interface CandidateScore {
  candidateId: number;
  name: string;
  overallScore: number;
  skillsScore: number;
  experienceScore: number;
  cultureFitScore: number;
  activityScore: number;
  availabilityPenalty: number;
  reasoning: string;
  strengths: string[];
  gaps: string[];
}

// ─── Availability multiplier ────────────────────────────────────────────────
// Applied AFTER LLM scoring using real Redrob signals.
// Never fed to the LLM — not gameable by profile content.
function computeAvailabilityMultiplier(c: Candidate): number {
  let m = 1.0;
  const sig = c.redrobSignals as Record<string, unknown> | null;

  // Days since last active
  const lastActive = c.lastActiveDate ?? (sig?.last_active_date as string | undefined);
  if (lastActive) {
    const days = Math.floor((Date.now() - new Date(lastActive).getTime()) / 86_400_000);
    if (days >= 180) m *= 0.55;
    else if (days >= 90) m *= 0.75;
    else if (days >= 45) m *= 0.88;
  }

  // Not open to work → slight down-weight (they may still respond, just less likely)
  if (c.openToWork === false) m *= 0.90;

  // Recruiter response rate
  const rrr = c.recruiterResponseRate ?? (sig?.recruiter_response_rate as number | undefined) ?? 1.0;
  if (rrr < 0.10) m *= 0.80;
  else if (rrr < 0.25) m *= 0.90;

  // Interview ghost rate — if they complete < 40% of scheduled interviews, down-weight hard
  const icr = c.interviewCompletionRate ?? (sig?.interview_completion_rate as number | undefined) ?? 1.0;
  if (icr < 0.30) m *= 0.82;
  else if (icr < 0.50) m *= 0.93;

  // Very slow response time (> 5 days average) — indicates low engagement
  const art = c.avgResponseTimeHours ?? (sig?.avg_response_time_hours as number | undefined) ?? 0;
  if (art > 168) m *= 0.90;

  return Math.max(0.10, m); // floor at 10% to avoid zeroing everyone out
}

// ─── Profile builder ─────────────────────────────────────────────────────────
// Builds a rich, structured text profile for the LLM.
// Availability signals are intentionally EXCLUDED.
function buildCandidateProfile(c: Candidate): string {
  const parts: string[] = [];

  parts.push(`Name: ${c.name}`);
  if (c.headline) parts.push(`Headline: ${c.headline}`);
  parts.push(`Current Role: ${c.currentTitle ?? "Unknown"} at ${c.currentCompany ?? "Unknown"}${c.currentCompanySize ? ` (${c.currentCompanySize} employees)` : ""}${c.currentIndustry ? `, ${c.currentIndustry}` : ""}`);
  parts.push(`Years of Experience: ${c.yearsExperience ?? "Unknown"}`);
  if (c.location) parts.push(`Location: ${c.location}${c.country && c.country !== c.location ? `, ${c.country}` : ""}`);
  if (c.summary) parts.push(`\nSummary:\n${c.summary}`);

  // Career history — the most important signal
  const career = c.careerHistory as Array<{
    company: string; title: string; start_date: string; end_date: string | null;
    duration_months: number; is_current: boolean; industry: string;
    company_size: string; description: string;
  }> | null;
  if (career && career.length > 0) {
    parts.push("\nCareer History:");
    for (const role of career) {
      const period = role.is_current
        ? `${role.start_date} – present (${role.duration_months}mo)`
        : `${role.start_date} – ${role.end_date ?? "?"} (${role.duration_months}mo)`;
      parts.push(`• ${role.title} @ ${role.company} [${role.company_size}, ${role.industry}] | ${period}`);
      if (role.description) parts.push(`  ${role.description.slice(0, 400)}`);
    }
  }

  // Education with tier
  const edu = c.education as Array<{
    institution: string; degree: string; field_of_study: string;
    start_year: number; end_year: number; grade: string | null; tier: string;
  }> | null;
  if (edu && edu.length > 0) {
    parts.push("\nEducation:");
    for (const e of edu) {
      const tierLabel = e.tier === "tier_1" ? " [Tier 1 institution]" :
                        e.tier === "tier_2" ? " [Tier 2]" : "";
      const grade = e.grade ? ` — ${e.grade}` : "";
      parts.push(`• ${e.institution}${tierLabel} — ${e.degree} in ${e.field_of_study} (${e.start_year}–${e.end_year})${grade}`);
    }
  }

  // Skills grouped by proficiency — critical for detecting keyword stuffers
  const skills = c.skills as Array<{
    name: string; proficiency: string; endorsements: number; duration_months: number;
  }> | null;
  if (skills && skills.length > 0) {
    const byLevel: Record<string, string[]> = { expert: [], advanced: [], intermediate: [], beginner: [] };
    for (const sk of skills) {
      const detail = `${sk.name} (${sk.duration_months}mo${sk.endorsements > 0 ? `, ${sk.endorsements} endorsements` : ""})`;
      const level = sk.proficiency?.toLowerCase() ?? "beginner";
      if (byLevel[level]) byLevel[level].push(detail);
    }
    parts.push("\nSkills:");
    if (byLevel.expert.length) parts.push(`  Expert: ${byLevel.expert.join(", ")}`);
    if (byLevel.advanced.length) parts.push(`  Advanced: ${byLevel.advanced.join(", ")}`);
    if (byLevel.intermediate.length) parts.push(`  Intermediate: ${byLevel.intermediate.join(", ")}`);
    if (byLevel.beginner.length) parts.push(`  Beginner: ${byLevel.beginner.join(", ")}`);
  }

  // Certifications
  const certs = c.certifications as Array<{ name: string; issuer: string; year: number }> | null;
  if (certs && certs.length > 0) {
    parts.push(`\nCertifications: ${certs.map(cert => `${cert.name} (${cert.issuer}, ${cert.year})`).join("; ")}`);
  }

  // GitHub activity (signal of real technical work)
  if (c.githubActivityScore != null && c.githubActivityScore >= 0) {
    parts.push(`\nGitHub Activity Score: ${c.githubActivityScore.toFixed(1)}/100 (based on commits, PRs, stars in last 12 months)`);
  }

  return parts.join("\n");
}

// ─── Pre-filter ───────────────────────────────────────────────────────────────
function preFilter(candidates: Candidate[], filters: RankingFilters): Candidate[] {
  return candidates.filter((c) => {
    if (filters.minExperience != null && (c.yearsExperience == null || c.yearsExperience < filters.minExperience)) return false;
    if (filters.maxExperience != null && c.yearsExperience != null && c.yearsExperience > filters.maxExperience) return false;
    if (filters.location && c.location) {
      if (!c.location.toLowerCase().includes(filters.location.toLowerCase()) &&
          !(c.country ?? "").toLowerCase().includes(filters.location.toLowerCase())) return false;
    }
    if (filters.educationLevel && c.education) {
      const edu = c.education as Array<{ degree: string }>;
      const hasLevel = edu.some(e => e.degree?.toLowerCase().includes(filters.educationLevel!.toLowerCase()));
      if (!hasLevel) return false;
    }
    return true;
  });
}

// ─── System prompt ────────────────────────────────────────────────────────────
const SYSTEM_PROMPT = `You are a senior technical recruiter and talent evaluator. Your job is to assess whether candidates are actually capable of doing a job — not whether their profile contains the right keywords.

## Core evaluation principles

### 1. Reason about what the job MEANS, not just what it SAYS
Job descriptions use specific terminology, but the underlying need may be broader. A JD asking for "RAG pipelines" and "Pinecone" is really asking for someone who understands retrieval systems, vector representations, and production LLM integration. A candidate who built a recommendation system with embeddings at a product company is a fit even if they've never used those brand names. Conversely, someone who lists those keywords as skills but whose entire career has been in marketing or business analysis is NOT a fit, regardless of their skills section.

### 2. Career function is the primary signal; skills list is secondary
Evaluate what this person has ACTUALLY DONE for a living. Their job title, company type, career history, and role descriptions establish their functional domain. Skills sections can be padded — career history and role descriptions cannot. If someone's entire career is in one domain (design, sales, finance, operations) but they list technical skills, treat those as surface-level familiarity unless backed by a role description or project evidence.

Ask: "Is this person's day-to-day work in the same function as this role?" If not, extraordinary evidence (published work, open source, assessments) is required to compensate.

### 3. Detect keyword inflation
If a candidate lists many role-relevant buzzwords in their skills section that don't appear in their career history or role descriptions, flag this as keyword inflation. Mark it as a gap. Do not boost their skillsScore just because of keyword matches.

### 4. Skills proficiency and duration matter
A skill listed as "beginner" with 3 months of use is fundamentally different from "expert" with 36 months and 12 endorsements. Weight accordingly. Beginner skills with short durations are not evidence of real capability.

### 5. Role descriptions over titles
The description of what someone actually did in a role matters more than the title. Read the descriptions carefully — the dataset intentionally contains mismatches where titles don't match descriptions.

### 6. Career trajectory and intentionality
A clear upward trajectory toward this function is a strong signal. A candidate three years into consistent ML engineering experience is often better than someone who dabbled for one year across many domains.

### 7. Education tier context
Tier 1 institutions (IITs, IISc, IIMs, top global universities) are a signal but not a requirement. A tier 3 graduate with strong career evidence beats a tier 1 graduate with weak functional experience every time.

## Scoring (0–100 each)

- **skillsScore**: Functional skill match inferred from career descriptions, role outputs, GitHub activity, and evidence of real practice. NOT from keyword overlap.
- **experienceScore**: Depth and relevance of experience — seniority level fit, domain match, trajectory toward this role.
- **cultureFitScore**: Working style fit — startup vs enterprise preference, ownership signals, communication clarity in summaries, career choices.
- **activityScore**: External technical signals — GitHub score, certifications with demonstrated use, community standing.

**overallScore** = skillsScore×0.35 + experienceScore×0.30 + cultureFitScore×0.20 + activityScore×0.15

Provide:
- **reasoning**: 2–3 sentences citing specific evidence. Name actual companies, roles, or projects. Not generic statements.
- **strengths**: 2–4 specific, evidence-backed strengths relevant to this role.
- **gaps**: 1–3 honest, specific gaps. If none, say so.`;

// ─── Batch scorer ─────────────────────────────────────────────────────────────
const BATCH_SIZE = 8; // smaller batches = more focused LLM attention per candidate

async function scoreBatch(
  candidates: Candidate[],
  jobDescription: string,
  jobTitle: string
): Promise<CandidateScore[]> {
  const profiles = candidates
    .map((c, i) => `--- CANDIDATE ${i + 1} (ID: ${c.id}) ---\n${buildCandidateProfile(c)}`)
    .join("\n\n");

  const userPrompt = `Evaluate each of the following ${candidates.length} candidates for this role.

JOB TITLE: ${jobTitle}

JOB DESCRIPTION:
${jobDescription}

---

${profiles}

---

Respond with ONLY valid JSON (no markdown, no commentary):
{
  "results": [
    {
      "candidateId": <number — the ID shown in the candidate block>,
      "overallScore": <number 0–100>,
      "skillsScore": <number 0–100>,
      "experienceScore": <number 0–100>,
      "cultureFitScore": <number 0–100>,
      "activityScore": <number 0–100>,
      "reasoning": "<2–3 sentences citing specific evidence from their profile>",
      "strengths": ["<specific strength with evidence>", ...],
      "gaps": ["<specific, honest gap>", ...]
    }
  ]
}`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    max_tokens: 4000,
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: userPrompt },
    ],
    response_format: { type: "json_object" },
    temperature: 0.1,
  });

  const content = response.choices[0]?.message?.content ?? "{}";

  let parsed: { results?: Array<{
    candidateId: number; overallScore: number; skillsScore: number;
    experienceScore: number; cultureFitScore: number; activityScore: number;
    reasoning: string; strengths: string[]; gaps: string[];
  }> };

  try {
    parsed = JSON.parse(content) as typeof parsed;
  } catch {
    logger.error({ content }, "Failed to parse LLM response");
    parsed = { results: [] };
  }

  return (parsed.results ?? []).map((r) => {
    const candidate = candidates.find((c) => c.id === r.candidateId);
    const availabilityMultiplier = candidate ? computeAvailabilityMultiplier(candidate) : 1.0;
    const rawOverall = Math.min(100, Math.max(0, r.overallScore ?? 0));
    const adjustedOverall = rawOverall * availabilityMultiplier;

    return {
      candidateId: r.candidateId,
      name: candidate?.name ?? "Unknown",
      overallScore: Math.round(adjustedOverall * 10) / 10,
      skillsScore: Math.min(100, Math.max(0, r.skillsScore ?? 0)),
      experienceScore: Math.min(100, Math.max(0, r.experienceScore ?? 0)),
      cultureFitScore: Math.min(100, Math.max(0, r.cultureFitScore ?? 0)),
      activityScore: Math.min(100, Math.max(0, r.activityScore ?? 0)),
      availabilityPenalty: Math.round((1 - availabilityMultiplier) * 100) / 100,
      reasoning: r.reasoning ?? "",
      strengths: r.strengths ?? [],
      gaps: r.gaps ?? [],
    };
  });
}

// ─── Main export ──────────────────────────────────────────────────────────────
export async function rankCandidates(
  candidates: Candidate[],
  jobDescription: string,
  jobTitle: string,
  filters: RankingFilters = {}
): Promise<CandidateScore[]> {
  const filtered = preFilter(candidates, filters);
  if (filtered.length === 0) return [];

  const batches: Candidate[][] = [];
  for (let i = 0; i < filtered.length; i += BATCH_SIZE) {
    batches.push(filtered.slice(i, i + BATCH_SIZE));
  }

  // Run batches with limited concurrency to avoid rate limits
  const results: CandidateScore[] = [];
  const CONCURRENCY = 4;
  for (let i = 0; i < batches.length; i += CONCURRENCY) {
    const chunk = batches.slice(i, i + CONCURRENCY);
    const chunkResults = await Promise.all(
      chunk.map((batch) => scoreBatch(batch, jobDescription, jobTitle))
    );
    results.push(...chunkResults.flat());
  }

  results.sort((a, b) => b.overallScore - a.overallScore);
  return results;
}
