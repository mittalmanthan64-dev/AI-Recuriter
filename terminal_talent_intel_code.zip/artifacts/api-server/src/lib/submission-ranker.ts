/**
 * CPU-only submission ranker for the Redrob Hackathon.
 * NO external API calls. Runs in <5 minutes on 100k candidates.
 * Primary signal: career function (what did they actually DO), not keyword overlap.
 */

import * as fs from "fs";
import * as readline from "readline";
import * as path from "path";

// ─── Types ────────────────────────────────────────────────────────────────────
export interface RawSkill {
  name: string;
  proficiency: "beginner" | "intermediate" | "advanced" | "expert";
  endorsements: number;
  duration_months: number;
}

export interface RawCareerRole {
  company: string;
  title: string;
  start_date: string;
  end_date: string | null;
  duration_months: number;
  is_current: boolean;
  industry: string;
  company_size: string;
  description: string;
}

export interface RawEducation {
  institution: string;
  degree: string;
  field_of_study: string;
  start_year: number;
  end_year: number;
  grade: string | null;
  tier: "tier_1" | "tier_2" | "tier_3" | "tier_4";
}

export interface RawSignals {
  profile_completeness_score: number;
  last_active_date: string;
  open_to_work_flag: boolean;
  recruiter_response_rate: number;
  avg_response_time_hours: number;
  notice_period_days: number;
  expected_salary_range_inr_lpa: { min: number; max: number };
  preferred_work_mode: string;
  willing_to_relocate: boolean;
  github_activity_score: number;
  interview_completion_rate: number;
  offer_acceptance_rate: number;
}

export interface RawCandidate {
  candidate_id: string;
  profile: {
    anonymized_name: string;
    headline: string;
    summary: string;
    location: string;
    country: string;
    years_of_experience: number;
    current_title: string;
    current_company: string;
    current_company_size: string;
    current_industry: string;
  };
  career_history: RawCareerRole[];
  education: RawEducation[];
  skills: RawSkill[];
  certifications: Array<{ name: string; issuer: string; year: number }>;
  redrob_signals: RawSignals;
}

export interface ScoredCandidate {
  candidateId: string;
  name: string;
  score: number;
  careerScore: number;
  skillsScore: number;
  expScore: number;
  eduScore: number;
  activityScore: number;
  availabilityMultiplier: number;
  isHoneypot: boolean;
  reasoning: string;
  raw: RawCandidate;
}

// ─── JD Signal Keywords ───────────────────────────────────────────────────────
// Senior AI Engineer @ Redrob AI — embedding, retrieval, ranking focus

// Title-level career function classification
const AI_ML_TITLE_KWS = [
  "machine learning", "ml engineer", "ml scientist", "ai engineer",
  "data scientist", "research scientist", "applied scientist", "applied ml",
  "nlp engineer", "nlp scientist", "computer vision", "deep learning engineer",
  "recommendation", "ranking engineer", "search engineer", "retrieval",
  "intelligence engineer", "algorithm engineer", "ml lead", "ai lead",
  "ml platform", "ai platform", "principal ml", "senior ml", "staff ml",
  "ml ops", "mlops engineer", "applied research", "ai researcher",
];

const SOFTWARE_ADJACENT_KWS = [
  "software engineer", "software developer", "backend engineer", "full stack",
  "platform engineer", "data engineer", "devops engineer", "site reliability",
  "sre", "cloud engineer", "infrastructure engineer", "solutions architect",
  "backend developer", "full-stack", "tech lead", "engineering manager",
];

const NON_TECH_KWS = [
  "marketing", "sales executive", "sales manager", "hr ", "human resource",
  "graphic design", "content writer", "content manager", "seo ", "copywriter",
  "accountant", "accounting", "finance manager", "civil engineer",
  "mechanical engineer", "customer support", "customer success",
  "operations manager", "project manager", "business analyst",
  "supply chain", "procurement", "logistics", "construction",
  "manufacturing", "quality assurance technician", "qa tester",
  "ux designer", "ui designer", "product designer", "art director",
  "social media", "digital marketing", "brand manager",
];

// Description-level evidence of AI/ML work (high value)
const DESC_HIGH_VALUE = [
  "embedding", "vector", "retrieval", "semantic search", "ranking",
  "recommendation", "reranking", "re-ranking", "re-rank",
  "llm", "large language model", "transformer", "bert", "gpt",
  "similarity search", "approximate nearest neighbor", "ann",
  "faiss", "pinecone", "weaviate", "qdrant", "milvus", "opensearch",
  "model training", "model serving", "model deployment", "inference",
  "fine-tun", "rlhf", "instruction tuning", "pretrain",
  "ndcg", "mrr", "map@", "precision@", "recall@",
  "production ml", "ml pipeline", "feature engineering at scale",
  "sentence-transformer", "bi-encoder", "cross-encoder",
  "dense retrieval", "hybrid search", "bm25",
  "neural search", "vector database", "vector store",
];

// Description-level ML work (medium value)
const DESC_MED_VALUE = [
  "machine learning", "deep learning", "neural network",
  "natural language", "nlp", "computer vision", "pytorch", "tensorflow",
  "scikit-learn", "hugging face", "huggingface", "langchain", "llamaindex",
  "classification", "regression", "clustering", "feature selection",
  "data pipeline", "etl", "spark", "kafka",
  "a/b test", "experiment", "metric", "evaluation framework",
];

// Skills that directly match the JD requirements
const RETRIEVAL_SKILL_KWS = new Set([
  "embeddings", "vector search", "faiss", "pinecone", "weaviate", "qdrant",
  "milvus", "chroma", "elasticsearch", "opensearch", "semantic search",
  "rag", "retrieval augmented generation", "retrieval", "reranking",
  "re-ranking", "bi-encoder", "cross-encoder", "dense retrieval",
  "hybrid search", "sentence-transformers", "sentence transformers",
  "bge", "e5 embeddings", "ada embeddings", "openai embeddings",
  "recommendation systems", "recommender", "collaborative filtering",
  "learning to rank", "ltr", "ranking", "vector database", "vector store",
  "approximate nearest neighbor", "ann", "similarity search",
]);

const ML_CORE_SKILL_KWS = new Set([
  "machine learning", "deep learning", "pytorch", "tensorflow", "jax",
  "nlp", "natural language processing", "transformers", "bert",
  "llm", "large language models", "scikit-learn", "sklearn",
  "python", "mlflow", "kubeflow", "sagemaker", "hugging face", "huggingface",
  "langchain", "llamaindex", "fine-tuning", "rlhf", "computer vision",
  "feature engineering", "model serving", "triton", "onnx",
  "data pipelines", "apache spark", "airflow",
]);

// ─── Honeypot Detection ───────────────────────────────────────────────────────
function detectHoneypot(c: RawCandidate): boolean {
  const skills = c.skills ?? [];

  // Trap 1: Expert skills with 0 months duration (impossibly claimed)
  const expertZero = skills.filter(
    (s) => s.proficiency === "expert" && s.duration_months === 0
  ).length;
  if (expertZero >= 4) return true;

  // Trap 2: All skills are "expert" with 10+ skills (unrealistic)
  if (skills.length >= 8 && skills.every((s) => s.proficiency === "expert")) return true;

  // Trap 3: Years of experience >> career history total (impossible timeline)
  const yoe = c.profile.years_of_experience ?? 0;
  const career = c.career_history ?? [];
  const totalCareerMonths = career.reduce((sum, r) => sum + (r.duration_months ?? 0), 0);
  if (yoe >= 3 && totalCareerMonths > 0) {
    const impliedYears = totalCareerMonths / 12;
    if (impliedYears < yoe * 0.25 && yoe - impliedYears > 6) return true;
  }

  // Trap 4: Advanced/expert on skills with 0 duration at high count
  const advancedZero = skills.filter(
    (s) =>
      (s.proficiency === "advanced" || s.proficiency === "expert") &&
      s.duration_months === 0
  ).length;
  if (advancedZero >= 7) return true;

  return false;
}

// ─── Career Function Score (0–100) ────────────────────────────────────────────
// Primary anti-keyword-stuffing signal: what did they DO at work?
function computeCareerScore(c: RawCandidate): number {
  const career = c.career_history ?? [];
  const currentTitle = (c.profile.current_title ?? "").toLowerCase();

  if (career.length === 0) return computeTitleScore(currentTitle) * 0.5;

  let weightedScore = 0;
  let totalWeight = 0;

  for (const role of career) {
    const titleScore = computeTitleScore(role.title.toLowerCase());
    const descScore = computeDescriptionScore(role.description ?? "");

    // Title = 60%, description content = 40%
    const roleScore = titleScore * 0.6 + descScore * 0.4;

    // Recency weight: current role counts 3x more
    const recencyW = role.is_current ? 3.0 : 1.5;
    const durationW = Math.max(1, role.duration_months ?? 1);

    weightedScore += roleScore * recencyW * durationW;
    totalWeight += recencyW * durationW;
  }

  const careerHistoryScore = totalWeight > 0 ? weightedScore / totalWeight : 20;

  // Boost if current title is strong AI/ML signal
  const currentTitleBoost = computeTitleScore(currentTitle);
  return careerHistoryScore * 0.7 + currentTitleBoost * 0.3;
}

function computeTitleScore(title: string): number {
  if (AI_ML_TITLE_KWS.some((kw) => title.includes(kw))) return 95;
  if (SOFTWARE_ADJACENT_KWS.some((kw) => title.includes(kw))) return 45;
  if (NON_TECH_KWS.some((kw) => title.includes(kw))) return 5;
  return 25; // ambiguous title
}

function computeDescriptionScore(desc: string): number {
  if (!desc || desc.length < 20) return 15;
  const d = desc.toLowerCase();
  const high = DESC_HIGH_VALUE.filter((kw) => d.includes(kw)).length;
  const med = DESC_MED_VALUE.filter((kw) => d.includes(kw)).length;
  const raw = high * 18 + med * 6;
  return Math.min(100, Math.max(5, raw));
}

// ─── Skills Depth Score (0–100) ───────────────────────────────────────────────
// Weights by proficiency × duration × endorsements — catches keyword inflation
function computeSkillsScore(c: RawCandidate): number {
  const skills = c.skills ?? [];
  let retrievalPts = 0;
  let mlCorePts = 0;

  for (const sk of skills) {
    const name = sk.name.toLowerCase();
    const prof = profWeight(sk.proficiency);
    const dur = durMultiplier(sk.duration_months);
    const endorseBonus = Math.min(0.25, sk.endorsements * 0.025);
    const wt = prof * dur + endorseBonus;

    if (isRetrievalSkill(name)) {
      retrievalPts += wt * 2.5; // retrieval skills are highly prized by JD
    } else if (isMLCoreSkill(name)) {
      mlCorePts += wt;
    }
  }

  return Math.min(100, retrievalPts * 20 + mlCorePts * 7);
}

function profWeight(p: string): number {
  switch (p) {
    case "expert": return 1.0;
    case "advanced": return 0.75;
    case "intermediate": return 0.40;
    case "beginner": return 0.08;
    default: return 0.05;
  }
}

function durMultiplier(months: number): number {
  if (months === 0) return 0.05; // 0-month "expert" = red flag
  if (months < 3) return 0.15;
  if (months < 6) return 0.35;
  if (months < 12) return 0.60;
  if (months < 24) return 0.85;
  return 1.0;
}

function isRetrievalSkill(name: string): boolean {
  return RETRIEVAL_SKILL_KWS.has(name) ||
    Array.from(RETRIEVAL_SKILL_KWS).some((kw) => name.includes(kw));
}

function isMLCoreSkill(name: string): boolean {
  return ML_CORE_SKILL_KWS.has(name) ||
    Array.from(ML_CORE_SKILL_KWS).some((kw) => name.includes(kw));
}

// ─── Experience Fit Score (0–100) ─────────────────────────────────────────────
// JD explicitly wants 5–9 years; soft bands around that
function computeExpScore(c: RawCandidate): number {
  const yoe = c.profile.years_of_experience ?? 0;
  if (yoe >= 5 && yoe <= 9) return 100;
  if (yoe === 4 || yoe === 10) return 85;
  if (yoe === 3 || (yoe >= 11 && yoe <= 12)) return 65;
  if (yoe === 2 || (yoe >= 13 && yoe <= 15)) return 45;
  if (yoe >= 16) return 30; // over-qualified/too senior for founding team
  return 20; // too junior
}

// ─── Education Score (0–100) ──────────────────────────────────────────────────
function computeEduScore(c: RawCandidate): number {
  const edu = c.education ?? [];
  if (edu.length === 0) return 30;

  let best = 30;
  for (const e of edu) {
    let score = 30;

    // Tier
    if (e.tier === "tier_1") score += 35;
    else if (e.tier === "tier_2") score += 20;
    else if (e.tier === "tier_3") score += 10;

    // Field
    const field = (e.field_of_study ?? "").toLowerCase();
    if (field.includes("computer") || field.includes("software") ||
        field.includes("machine learning") || field.includes("data science") ||
        field.includes("ai") || field.includes("artificial intelligence") ||
        field.includes("nlp") || field.includes("information technology")) {
      score += 20;
    } else if (field.includes("math") || field.includes("statistic") ||
               field.includes("electrical") || field.includes("electronics")) {
      score += 12;
    }

    // Degree level
    const deg = (e.degree ?? "").toLowerCase();
    if (deg.includes("ph.d") || deg.includes("phd") || deg.includes("doctor")) score += 10;
    else if (deg.includes("m.tech") || deg.includes("m.s") || deg.includes("master")) score += 8;

    best = Math.max(best, score);
  }
  return Math.min(100, best);
}

// ─── Activity Score (0–100) ───────────────────────────────────────────────────
function computeActivityScore(c: RawCandidate): number {
  const sig = c.redrob_signals ?? {} as RawSignals;
  let score = 40; // baseline

  // GitHub activity is a strong real-code signal
  const gh = sig.github_activity_score ?? -1;
  if (gh >= 0) {
    score += gh * 0.4; // max +40 pts for perfect GitHub
  }

  // Profile completeness
  score += (sig.profile_completeness_score ?? 50) * 0.15;

  // Certifications
  const certs = c.certifications ?? [];
  const aiCerts = certs.filter((cert) => {
    const n = cert.name.toLowerCase();
    return n.includes("aws") || n.includes("gcp") || n.includes("azure") ||
           n.includes("tensorflow") || n.includes("pytorch") ||
           n.includes("machine learning") || n.includes("deep learning") ||
           n.includes("data science") || n.includes("ai");
  }).length;
  score += Math.min(10, aiCerts * 5);

  return Math.min(100, score);
}

// ─── Availability Multiplier (0.1–1.0) ────────────────────────────────────────
function computeAvailabilityMultiplier(c: RawCandidate): number {
  const sig = c.redrob_signals ?? {} as RawSignals;
  let m = 1.0;

  // Days since last active
  if (sig.last_active_date) {
    const days = Math.floor(
      (Date.now() - new Date(sig.last_active_date).getTime()) / 86_400_000
    );
    if (days >= 180) m *= 0.55;
    else if (days >= 90) m *= 0.75;
    else if (days >= 45) m *= 0.88;
  }

  // Not open to work
  if (sig.open_to_work_flag === false) m *= 0.90;

  // Recruiter response rate
  const rrr = sig.recruiter_response_rate ?? 1.0;
  if (rrr < 0.10) m *= 0.80;
  else if (rrr < 0.25) m *= 0.92;

  // Interview ghost rate
  const icr = sig.interview_completion_rate ?? 1.0;
  if (icr < 0.30) m *= 0.82;
  else if (icr < 0.50) m *= 0.93;

  // Very slow response time
  const art = sig.avg_response_time_hours ?? 0;
  if (art > 168) m *= 0.90;

  return Math.max(0.12, m);
}

// ─── Reasoning Generator ──────────────────────────────────────────────────────
function generateReasoning(c: RawCandidate, s: ScoredCandidate, rank: number): string {
  const p = c.profile;
  const sig = c.redrob_signals ?? {} as RawSignals;

  // Find strongest retrieval/ML skills
  const skills = (c.skills ?? [])
    .filter((sk) => (sk.proficiency === "expert" || sk.proficiency === "advanced") && sk.duration_months >= 6)
    .sort((a, b) => profWeight(b.proficiency) * b.duration_months - profWeight(a.proficiency) * a.duration_months)
    .slice(0, 3)
    .map((sk) => `${sk.name} (${sk.proficiency}, ${sk.duration_months}mo)`);

  // Most relevant role
  const aiRoles = (c.career_history ?? []).filter((r) =>
    AI_ML_TITLE_KWS.some((kw) => r.title.toLowerCase().includes(kw))
  );
  const topRole = aiRoles[0] ?? (c.career_history ?? [])[0];

  // Availability note
  const noticeStr = sig.notice_period_days === 0
    ? "immediate availability"
    : `${sig.notice_period_days}-day notice`;
  const statusStr = sig.open_to_work_flag ? "actively looking" : "passive";

  // Days since active
  const daysInactive = sig.last_active_date
    ? Math.floor((Date.now() - new Date(sig.last_active_date).getTime()) / 86_400_000)
    : null;

  const availNote = daysInactive != null && daysInactive >= 45
    ? `; inactive ${daysInactive}d (availability penalty applied)`
    : "";

  if (rank <= 15) {
    // Top tier: specific, positive, cite evidence
    const roleDesc = topRole
      ? `${topRole.duration_months}mo at ${topRole.company} as ${topRole.title}`
      : `${p.years_of_experience}y in ${p.current_industry}`;
    const skillStr = skills.length > 0 ? `; skills include ${skills.join(", ")}` : "";
    return `${p.current_title} at ${p.current_company} with ${p.years_of_experience}y exp; ${roleDesc}${skillStr}; ${statusStr}, ${noticeStr}${availNote}.`;
  } else if (rank <= 40) {
    // Mid tier: mention match and a relevant concern
    const gapNote = s.careerScore < 50
      ? `career history primarily in ${p.current_industry || "non-ML domains"}, limited production ML evidence`
      : s.skillsScore < 30
      ? "skills list lacks depth in retrieval/embedding stack"
      : "solid experience but lower retrieval-system specificity";
    return `${p.current_title} with ${p.years_of_experience}y exp; ${gapNote}; ${statusStr}, ${noticeStr}${availNote}.`;
  } else {
    // Lower tier: honest about the gap
    const gap = s.careerScore < 40
      ? `career function mismatch (${p.current_title})`
      : s.expScore < 60
      ? `experience outside target range (${p.years_of_experience}y)`
      : "insufficient retrieval/ML production evidence";
    return `${gap}; included based on ${p.years_of_experience}y tenure and partial skill overlap; ${statusStr}${availNote}.`;
  }
}

// ─── Main Scorer ──────────────────────────────────────────────────────────────
export function scoreCandidate(c: RawCandidate): ScoredCandidate {
  const honeypot = detectHoneypot(c);
  if (honeypot) {
    return {
      candidateId: c.candidate_id,
      name: c.profile.anonymized_name,
      score: 0,
      careerScore: 0,
      skillsScore: 0,
      expScore: 0,
      eduScore: 0,
      activityScore: 0,
      availabilityMultiplier: 0,
      isHoneypot: true,
      reasoning: "Honeypot candidate: profile has impossible signal combinations.",
      raw: c,
    };
  }

  const careerScore = computeCareerScore(c);
  const skillsScore = computeSkillsScore(c);
  const expScore = computeExpScore(c);
  const eduScore = computeEduScore(c);
  const activityScore = computeActivityScore(c);

  const rawScore =
    careerScore * 0.40 +
    skillsScore * 0.25 +
    expScore * 0.15 +
    eduScore * 0.10 +
    activityScore * 0.10;

  const availMult = computeAvailabilityMultiplier(c);
  const finalScore = (rawScore / 100) * availMult;

  const scored: ScoredCandidate = {
    candidateId: c.candidate_id,
    name: c.profile.anonymized_name,
    score: finalScore,
    careerScore,
    skillsScore,
    expScore,
    eduScore,
    activityScore,
    availabilityMultiplier: availMult,
    isHoneypot: false,
    reasoning: "",
    raw: c,
  };

  return scored;
}

// ─── Generate Submission CSV ──────────────────────────────────────────────────
export interface SubmissionOptions {
  jsonlPath: string;
  topN?: number;
  onProgress?: (processed: number) => void;
}

export interface SubmissionRow {
  candidate_id: string;
  rank: number;
  score: number;
  reasoning: string;
}

export async function generateSubmission(opts: SubmissionOptions): Promise<SubmissionRow[]> {
  const { jsonlPath, topN = 100, onProgress } = opts;

  // Use a scored array capped at topN * 10 for memory efficiency
  // We keep the top 1000 candidates throughout streaming to save memory
  const KEEP_TOP = 1000;
  let topList: ScoredCandidate[] = [];
  let minScoreInList = 0;
  let processed = 0;

  const stream = fs.createReadStream(jsonlPath, { encoding: "utf8" });
  const rl = readline.createInterface({ input: stream, crlfDelay: Infinity });

  for await (const line of rl) {
    if (!line.trim()) continue;
    try {
      const candidate: RawCandidate = JSON.parse(line);
      const scored = scoreCandidate(candidate);

      // Only keep if it might make the top list
      if (topList.length < KEEP_TOP || scored.score > minScoreInList) {
        topList.push(scored);
        if (topList.length > KEEP_TOP) {
          // Trim: sort and slice
          topList.sort((a, b) => b.score - a.score);
          topList = topList.slice(0, KEEP_TOP);
          minScoreInList = topList[KEEP_TOP - 1].score;
        }
      }

      processed++;
      if (processed % 5000 === 0 && onProgress) {
        onProgress(processed);
      }
    } catch {
      // Skip malformed lines
    }
  }

  // Final sort
  topList.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    return a.candidateId.localeCompare(b.candidateId); // tie-break: candidate_id ascending per spec
  });

  const top = topList.slice(0, topN);

  // Generate reasonings for top N only
  const rows: SubmissionRow[] = top.map((s, i) => {
    const rank = i + 1;
    const reasoning = generateReasoning(s.raw, s, rank);
    // Ensure score is monotonically non-increasing (it is by construction; just normalize)
    const scoreNormalized = Math.min(0.9999, Math.max(0.0001, s.score));
    return {
      candidate_id: s.candidateId,
      rank,
      score: Math.round(scoreNormalized * 10000) / 10000,
      reasoning,
    };
  });

  // Ensure scores are strictly non-increasing (tie-break already resolved)
  for (let i = 1; i < rows.length; i++) {
    if (rows[i].score > rows[i - 1].score) {
      rows[i].score = rows[i - 1].score;
    }
  }

  return rows;
}

export function rowsToCsv(rows: SubmissionRow[]): string {
  const header = "candidate_id,rank,score,reasoning";
  const dataRows = rows.map((r) => {
    const esc = (v: string) => {
      if (v.includes(",") || v.includes('"') || v.includes("\n")) {
        return `"${v.replace(/"/g, '""')}"`;
      }
      return v;
    };
    return `${r.candidate_id},${r.rank},${r.score.toFixed(4)},${esc(r.reasoning)}`;
  });
  return [header, ...dataRows].join("\n");
}
