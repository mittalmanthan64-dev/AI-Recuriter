import React from "react";
import { Link, useLocation } from "wouter";
import { Activity, Users, BarChart2, Zap, Settings, CheckCircle2, Trophy } from "lucide-react";
import { cn } from "@/lib/utils";
import { useHealthCheck, getHealthCheckQueryKey } from "@workspace/api-client-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Dashboard", icon: BarChart2 },
    { href: "/rank", label: "Rank Candidates", icon: Zap },
    { href: "/candidates", label: "Candidate Pool", icon: Users },
    { href: "/submission", label: "Hackathon Submit", icon: Trophy },
  ];

  const { data: healthStatus } = useHealthCheck({
    query: { queryKey: getHealthCheckQueryKey() }
  });

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 border-r border-border bg-card flex flex-col">
        <div className="p-6 border-b border-border flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-primary flex items-center justify-center text-primary-foreground font-bold">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-bold tracking-tight leading-none">TERMINAL</h1>
            <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-mono mt-0.5">Talent Intel</p>
          </div>
        </div>

        <nav className="flex-1 py-6 px-3 flex flex-col gap-1">
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            return (
              <Link key={item.href} href={item.href}>
                <div
                  data-testid={`nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors cursor-pointer",
                    isActive
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                  )}
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </div>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-border space-y-4">
          <div className="flex items-center gap-2 px-3">
            {healthStatus?.status === "ok" ? (
              <CheckCircle2 className="w-3 h-3 text-primary" />
            ) : (
              <div className="w-3 h-3 rounded-full bg-destructive" />
            )}
            <span className="text-xs font-mono text-muted-foreground">
              API {healthStatus?.status === "ok" ? "ONLINE" : "OFFLINE"}
            </span>
          </div>

          <div className="flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:bg-secondary cursor-pointer">
            <Settings className="w-4 h-4" />
            Settings
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto bg-background">
        {children}
      </main>
    </div>
  );
}
