import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useRunRanking } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScoreRing, ScoreBar } from "@/components/score-ring";
import {
  Loader2, Zap, CheckCircle2, AlertTriangle, TrendingDown,
  UserX, Clock, Briefcase, MapPin, GraduationCap, Github,
  BadgeCheck, MonitorSmartphone, Home, Building2, Globe
} from "lucide-react";

const rankFormSchema = z.object({
  jobTitle: z.string().min(1, "Job title is required"),
  jobDescription: z.string().min(10, "Must be at least 10 characters"),
  minExperience: z.string().optional(),
  maxExperience: z.string().optional(),
  location: z.string().optional(),
  educationLevel: z.string().optional(),
});
type RankFormValues = z.infer<typeof rankFormSchema>;

const PROFICIENCY_COLORS: Record<string, string> = {
  expert: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
  advanced: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  intermediate: "bg-yellow-500/20 text-yellow-500 border-yellow-500/30",
  beginner: "bg-zinc-500/20 text-zinc-400 border-zinc-500/30",
};

const WORK_MODE_ICONS: Record<string, React.ReactNode> = {
  remote: <Globe className="w-3 h-3" />,
  hybrid: <MonitorSmartphone className="w-3 h-3" />,
  onsite: <Building2 className="w-3 h-3" />,
  flexible: <Home className="w-3 h-3" />,
};

export function Rank() {
  const [results, setResults] = useState<any>(null);
  const form = useForm<RankFormValues>({
    resolver: zodResolver(rankFormSchema),
    defaultValues: { jobTitle: "", jobDescription: "", minExperience: "", maxExperience: "", location: "", educationLevel: "" },
  });
  const runRanking = useRunRanking();

  function onSubmit(data: RankFormValues) {
    runRanking.mutate(
      {
        data: {
          jobTitle: data.jobTitle,
          jobDescription: data.jobDescription,
          filters: {
            minExperience: data.minExperience ? parseInt(data.minExperience, 10) : undefined,
            maxExperience: data.maxExperience ? parseInt(data.maxExperience, 10) : undefined,
            location: data.location || undefined,
            educationLevel: data.educationLevel || undefined,
          },
        }
      },
      { onSuccess: (data) => setResults(data) }
    );
  }

  return (
    <div className="p-8 max-w-6xl mx-auto flex flex-col gap-8 h-[calc(100vh-4rem)]">
      <div className="shrink-0">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Rank Candidates</h1>
        <p className="text-muted-foreground mt-1">Semantic AI ranking — evaluates career function and trajectory, not keyword overlap.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 min-h-0">
        {/* Form */}
        <div className="lg:col-span-4 overflow-y-auto pr-2 pb-8">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground border-b border-border pb-2">Target Role</h3>
                <FormField control={form.control} name="jobTitle" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Job Title</FormLabel>
                    <FormControl><Input placeholder="e.g. Senior AI Engineer" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="jobDescription" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Job Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Paste the full job description here..." className="min-h-[180px] font-mono text-xs resize-y" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground border-b border-border pb-2">Hard Filters</h3>
                <div className="grid grid-cols-2 gap-3">
                  <FormField control={form.control} name="minExperience" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Min Yrs Exp</FormLabel>
                      <FormControl><Input type="number" placeholder="0" {...field} /></FormControl>
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="maxExperience" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Max Yrs Exp</FormLabel>
                      <FormControl><Input type="number" placeholder="20" {...field} /></FormControl>
                    </FormItem>
                  )} />
                </div>
                <FormField control={form.control} name="location" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl><Input placeholder="e.g. Bangalore, India" {...field} /></FormControl>
                  </FormItem>
                )} />
                <FormField control={form.control} name="educationLevel" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Degree</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger><SelectValue placeholder="Any degree" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="any">Any</SelectItem>
                        <SelectItem value="B.Tech">B.Tech / B.E.</SelectItem>
                        <SelectItem value="M.Tech">M.Tech / M.E.</SelectItem>
                        <SelectItem value="MBA">MBA</SelectItem>
                        <SelectItem value="Ph.D">PhD</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )} />
              </div>

              <Button type="submit" className="w-full h-11 font-semibold" disabled={runRanking.isPending}>
                {runRanking.isPending ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Analyzing {results ? "again" : "candidates"}...</> : <><Zap className="mr-2 h-4 w-4" />Run Intelligence Ranking</>}
              </Button>
            </form>
          </Form>
        </div>

        {/* Results */}
        <div className="lg:col-span-8 bg-card border border-border rounded-lg overflow-hidden flex flex-col">
          {runRanking.isPending ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
              <Loader2 className="w-10 h-10 text-primary animate-spin mb-4" />
              <h3 className="text-lg font-bold">Reading Career Trajectories</h3>
              <p className="text-muted-foreground mt-2 text-sm max-w-sm">Evaluating functional fit, work history, and availability signals across all candidates...</p>
              <div className="mt-6 space-y-2 w-56">
                {[0.66, 0.4, 0.53].map((w, i) => (
                  <div key={i} className="h-1.5 w-full bg-secondary rounded-full overflow-hidden">
                    <div className="h-full bg-primary animate-pulse" style={{ width: `${w * 100}%` }} />
                  </div>
                ))}
              </div>
            </div>
          ) : results ? (
            <>
              <div className="px-4 py-3 border-b border-border bg-secondary/20 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                  <span className="font-semibold text-sm">Analysis Complete</span>
                  <span className="text-xs text-muted-foreground">· {results.totalEvaluated} candidates evaluated · scores include availability weighting</span>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {results.rankedCandidates.map((candidate: any, idx: number) => (
                  <RankedCandidateCard key={candidate.candidateId} candidate={candidate} rank={idx + 1} />
                ))}
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-muted-foreground border-dashed border-2 border-border m-4 rounded-lg">
              <Zap className="w-10 h-10 mb-3 opacity-20" />
              <h3 className="font-semibold mb-1">Ready to Rank</h3>
              <p className="text-sm max-w-xs">Paste a job description and the AI will surface the best-fit candidates — reasoning about what the role means, not just what it says.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Availability warning badge ───────────────────────────────────────────────
function AvailabilityBadge({ candidate }: { candidate: any }) {
  const penalty = candidate.availabilityPenalty ?? 0;
  if (penalty < 0.05) return null;

  const pct = Math.round(penalty * 100);
  const days = candidate.daysInactive ?? computeDaysInactive(candidate.lastActiveDate);
  const rrr = candidate.recruiterResponseRate;
  const icr = candidate.interviewCompletionRate;

  const reasons: string[] = [];
  if (days != null && days >= 45) reasons.push(`${days}d inactive`);
  if (rrr != null && rrr < 0.25) reasons.push(`${Math.round(rrr * 100)}% response rate`);
  if (icr != null && icr < 0.5) reasons.push(`${Math.round(icr * 100)}% interview completion`);
  if (!candidate.openToWork) reasons.push("not open to work");

  const isSevere = pct >= 35;
  return (
    <div className={`flex items-start gap-1.5 border rounded px-2.5 py-1.5 text-xs ${isSevere ? "border-red-500/30 bg-red-500/8 text-red-400" : "border-amber-500/30 bg-amber-500/8 text-amber-500"}`}>
      {isSevere ? <UserX className="w-3.5 h-3.5 shrink-0 mt-0.5" /> : <TrendingDown className="w-3.5 h-3.5 shrink-0 mt-0.5" />}
      <span><span className="font-semibold">−{pct}% availability penalty</span>{reasons.length > 0 && <span className="opacity-75"> · {reasons.join(" · ")}</span>}</span>
    </div>
  );
}

function computeDaysInactive(lastActiveDate: string | null | undefined): number | null {
  if (!lastActiveDate) return null;
  return Math.floor((Date.now() - new Date(lastActiveDate).getTime()) / 86_400_000);
}

// ─── Skills pills with proficiency color ─────────────────────────────────────
function SkillPills({ skills, limit = 8 }: { skills: Array<{ name: string; proficiency: string }> | null | undefined; limit?: number }) {
  if (!skills || skills.length === 0) return null;
  const sorted = [...skills].sort((a, b) => {
    const order = ["expert", "advanced", "intermediate", "beginner"];
    return order.indexOf(a.proficiency) - order.indexOf(b.proficiency);
  });
  const shown = sorted.slice(0, limit);
  const remaining = skills.length - shown.length;
  return (
    <div className="flex flex-wrap gap-1 mt-2">
      {shown.map((s) => (
        <span key={s.name} className={`px-1.5 py-0.5 rounded text-[10px] border font-medium ${PROFICIENCY_COLORS[s.proficiency] ?? PROFICIENCY_COLORS.beginner}`}>
          {s.name}
        </span>
      ))}
      {remaining > 0 && <span className="text-[10px] text-muted-foreground self-center">+{remaining}</span>}
    </div>
  );
}

// ─── Candidate signal chips ───────────────────────────────────────────────────
function SignalChips({ candidate }: { candidate: any }) {
  const chips: React.ReactNode[] = [];

  if (candidate.openToWork) {
    chips.push(
      <span key="otw" className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/25">
        <BadgeCheck className="w-3 h-3" /> Open to Work
      </span>
    );
  }

  if (candidate.noticePeriodDays != null) {
    chips.push(
      <span key="notice" className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] text-muted-foreground border border-border bg-secondary/50">
        <Clock className="w-3 h-3" /> {candidate.noticePeriodDays === 0 ? "Immediate" : `${candidate.noticePeriodDays}d notice`}
      </span>
    );
  }

  if (candidate.expectedSalaryMin != null && candidate.expectedSalaryMax != null) {
    chips.push(
      <span key="salary" className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] text-muted-foreground border border-border bg-secondary/50">
        ₹{candidate.expectedSalaryMin}–{candidate.expectedSalaryMax} LPA
      </span>
    );
  }

  if (candidate.preferredWorkMode) {
    chips.push(
      <span key="mode" className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] text-muted-foreground border border-border bg-secondary/50 capitalize">
        {WORK_MODE_ICONS[candidate.preferredWorkMode]} {candidate.preferredWorkMode}
      </span>
    );
  }

  if (candidate.willingToRelocate) {
    chips.push(
      <span key="relocate" className="px-2 py-0.5 rounded-full text-[10px] text-blue-400 border border-blue-500/25 bg-blue-500/10">
        Open to relocate
      </span>
    );
  }

  if (candidate.githubActivityScore != null && candidate.githubActivityScore >= 0) {
    chips.push(
      <span key="gh" className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] text-muted-foreground border border-border bg-secondary/50">
        <Github className="w-3 h-3" /> GH {candidate.githubActivityScore.toFixed(0)}/100
      </span>
    );
  }

  return chips.length > 0 ? <div className="flex flex-wrap gap-1.5 mt-2">{chips}</div> : null;
}

// ─── Main candidate card ──────────────────────────────────────────────────────
export function RankedCandidateCard({ candidate, rank }: { candidate: any; rank: number }) {
  const hasAvailabilityPenalty = (candidate.availabilityPenalty ?? 0) >= 0.05;
  const skills = candidate.skills as Array<{ name: string; proficiency: string }> | null;

  return (
    <div className={`border rounded-lg bg-background p-5 transition-colors hover:border-primary/40 ${hasAvailabilityPenalty ? "border-border/50 opacity-90" : "border-border"}`}>
      <div className="flex flex-col md:flex-row gap-5">
        {/* Left: identity + reasoning */}
        <div className="flex-1 min-w-0 space-y-3">
          {/* Header row */}
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                <span className="bg-primary/15 text-primary font-mono text-xs px-2 py-0.5 rounded font-bold shrink-0">#{rank}</span>
                <h3 className="font-bold text-base leading-tight">{candidate.name}</h3>
                {candidate.candidateId && (
                  <span className="text-[10px] text-muted-foreground font-mono opacity-50">{candidate.candidateId}</span>
                )}
              </div>
              <p className="text-sm text-muted-foreground font-medium">
                {candidate.currentTitle}{candidate.currentCompany ? <span> · <span className="text-foreground/80">{candidate.currentCompany}</span></span> : null}
                {candidate.currentCompanySize && <span className="text-xs opacity-60"> ({candidate.currentCompanySize})</span>}
              </p>
              <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground mt-1">
                {candidate.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{candidate.location}</span>}
                {candidate.yearsExperience != null && <span className="flex items-center gap-1"><Briefcase className="w-3 h-3" />{candidate.yearsExperience}y exp</span>}
                {candidate.currentIndustry && <span className="opacity-60">{candidate.currentIndustry}</span>}
              </div>
            </div>
            <ScoreRing score={candidate.overallScore} size={52} strokeWidth={4} label="Match" />
          </div>

          {/* Availability warning */}
          {hasAvailabilityPenalty && <AvailabilityBadge candidate={candidate} />}

          {/* Signal chips */}
          <SignalChips candidate={candidate} />

          {/* Skills */}
          <SkillPills skills={skills} />

          {/* AI reasoning */}
          <div className="bg-secondary/25 border border-border/50 rounded p-3 text-xs leading-relaxed text-muted-foreground">
            <span className="text-foreground font-semibold">AI Reasoning: </span>{candidate.reasoning}
          </div>

          {/* Strengths + Gaps */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {candidate.strengths?.length > 0 && (
              <div>
                <h4 className="text-[10px] font-semibold text-primary uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Strengths
                </h4>
                <ul className="space-y-1">
                  {candidate.strengths.map((s: string, i: number) => (
                    <li key={i} className="text-xs text-muted-foreground flex items-start gap-1.5">
                      <span className="text-primary mt-0.5">•</span>{s}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {candidate.gaps?.length > 0 && (
              <div>
                <h4 className="text-[10px] font-semibold text-amber-500 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" /> Gaps
                </h4>
                <ul className="space-y-1">
                  {candidate.gaps.map((g: string, i: number) => (
                    <li key={i} className="text-xs text-muted-foreground flex items-start gap-1.5">
                      <span className="text-amber-500 mt-0.5">•</span>{g}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>

        {/* Right: score bars */}
        <div className="md:w-44 shrink-0 space-y-2.5 pt-1">
          <ScoreBar score={candidate.skillsScore || 0} label="Skills" />
          <ScoreBar score={candidate.experienceScore || 0} label="Experience" />
          <ScoreBar score={candidate.cultureFitScore || 0} label="Culture" />
          <ScoreBar score={candidate.activityScore || 0} label="Activity" />
          {candidate.recruiterResponseRate != null && (
            <div className="pt-1 border-t border-border/50">
              <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
                <span>Resp. Rate</span>
                <span>{Math.round(candidate.recruiterResponseRate * 100)}%</span>
              </div>
              <div className="h-1 bg-secondary rounded-full overflow-hidden">
                <div className="h-full bg-blue-500/60 rounded-full" style={{ width: `${candidate.recruiterResponseRate * 100}%` }} />
              </div>
            </div>
          )}
          {candidate.interviewCompletionRate != null && (
            <div>
              <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
                <span>Interview Completion</span>
                <span>{Math.round(candidate.interviewCompletionRate * 100)}%</span>
              </div>
              <div className="h-1 bg-secondary rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${candidate.interviewCompletionRate < 0.5 ? "bg-amber-500/60" : "bg-emerald-500/60"}`}
                  style={{ width: `${candidate.interviewCompletionRate * 100}%` }}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
