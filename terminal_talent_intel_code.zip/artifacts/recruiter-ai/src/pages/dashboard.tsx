import React from "react";
import { useGetStats, useListRankingSessions, getGetStatsQueryKey, getListRankingSessionsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { ArrowRight, Users, Zap, Clock, Briefcase } from "lucide-react";
import { format } from "date-fns";

export function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useGetStats({
    query: { queryKey: getGetStatsQueryKey() }
  });

  const { data: sessions, isLoading: sessionsLoading } = useListRankingSessions({
    query: { queryKey: getListRankingSessionsQueryKey() }
  });

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Overview of your talent pool and intelligence runs.</p>
        </div>
        <Link href="/rank">
          <div className="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground shadow hover:bg-primary/90 h-9 px-4 py-2 cursor-pointer">
            <Zap className="w-4 h-4" />
            New Ranking Run
          </div>
        </Link>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Total Candidates" 
          value={stats?.totalCandidates} 
          icon={Users} 
          loading={statsLoading} 
        />
        <StatCard 
          title="Intelligence Runs" 
          value={stats?.totalSessions} 
          icon={Zap} 
          loading={statsLoading} 
        />
        <StatCard 
          title="Avg Experience" 
          value={stats?.avgExperience ? `${stats.avgExperience.toFixed(1)} yrs` : undefined} 
          icon={Clock} 
          loading={statsLoading} 
        />
        <StatCard 
          title="Top Skills Tracked" 
          value={stats?.topSkills?.length} 
          icon={Briefcase} 
          loading={statsLoading} 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Sessions */}
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-xl font-semibold tracking-tight">Recent Ranking Sessions</h2>
          {sessionsLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-24 w-full" />)}
            </div>
          ) : sessions?.length ? (
            <div className="space-y-3">
              {sessions.slice(0, 5).map(session => (
                <Link key={session.id} href={`/sessions/${session.id}`}>
                  <Card className="hover:border-primary/50 transition-colors cursor-pointer group">
                    <CardContent className="p-4 flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold text-lg">{session.jobTitle}</h3>
                        <p className="text-sm text-muted-foreground flex items-center gap-2 mt-1">
                          <Clock className="w-3 h-3" />
                          {format(new Date(session.createdAt), "MMM d, yyyy h:mm a")}
                          <span className="mx-2">&bull;</span>
                          <Users className="w-3 h-3" />
                          {session.totalCandidates} evaluated
                        </p>
                      </div>
                      <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-8 text-center text-muted-foreground">
                <Zap className="w-8 h-8 mx-auto mb-3 opacity-20" />
                <p>No ranking sessions found.</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Intelligence distribution */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold tracking-tight">Top Skills in Pool</h2>
          <Card>
            <CardContent className="p-6">
              {statsLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3, 4, 5].map(i => <Skeleton key={i} className="h-4 w-full" />)}
                </div>
              ) : stats?.topSkills?.length ? (
                <div className="flex flex-wrap gap-2">
                  {stats.topSkills.map(skill => (
                    <span key={skill} className="px-2.5 py-1 rounded bg-secondary text-secondary-foreground text-xs font-medium border border-border">
                      {skill}
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center">Not enough data.</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon: Icon, loading }: { title: string, value?: string | number, icon: any, loading: boolean }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <Icon className="w-4 h-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        {loading ? (
          <Skeleton className="h-8 w-20" />
        ) : (
          <div className="text-2xl font-bold font-mono">{value ?? "-"}</div>
        )}
      </CardContent>
    </Card>
  );
}
