import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Download, Loader2, CheckCircle2, AlertTriangle, Trophy,
  Cpu, Clock, ShieldCheck, FileText, ChevronDown, ChevronUp,
  ExternalLink, Info
} from "lucide-react";

interface SubmissionResult {
  csv: string;
  rows: Array<{ candidate_id: string; rank: number; score: number; reasoning: string }>;
  stats: { totalProcessed: number; elapsed?: number; honeypotCount?: number; topCandidate?: { id: string; score: number; careerScore?: number } | null };
  mode: "sample" | "full";
}

const BASE = import.meta.env.BASE_URL;

async function callGenerateSubmission(sampleOnly: boolean): Promise<SubmissionResult> {
  const res = await fetch(`${BASE}api/submission/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sampleOnly }),
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json() as Promise<SubmissionResult>;
}

function downloadCsv(csv: string, filename: string) {
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function Submission() {
  const [result, setResult] = useState<SubmissionResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showAll, setShowAll] = useState(false);

  const run = async (sampleOnly: boolean) => {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const data = await callGenerateSubmission(sampleOnly);
      setResult(data);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Unknown error");
    } finally {
      setLoading(false);
    }
  };

  const displayRows = result
    ? showAll ? result.rows : result.rows.slice(0, 10)
    : [];

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-3 mb-1">
          <Trophy className="w-6 h-6 text-amber-400" />
          <h1 className="text-3xl font-bold tracking-tight">Hackathon Submission</h1>
        </div>
        <p className="text-muted-foreground">
          Generate the challenge CSV — CPU-only ranker, no API calls, runs in &lt;5 min on 100k candidates.
        </p>
      </div>

      {/* Challenge info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 flex items-start gap-3">
            <Cpu className="w-4 h-4 text-primary shrink-0 mt-1" />
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Compute Constraints</p>
              <p className="text-sm mt-1">CPU only · No API calls · ≤5 min · ≤16 GB RAM</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-start gap-3">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-1" />
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Honeypot Guard</p>
              <p className="text-sm mt-1">Detects impossible profiles (expert skills, 0 months; timeline fraud)</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-start gap-3">
            <FileText className="w-4 h-4 text-blue-400 shrink-0 mt-1" />
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Output Format</p>
              <p className="text-sm mt-1">Top 100 · CSV · candidate_id, rank, score, reasoning</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Algorithm overview */}
      <Card>
        <CardContent className="p-5 space-y-3">
          <h3 className="font-semibold flex items-center gap-2">
            <Info className="w-4 h-4 text-muted-foreground" />
            Ranker Architecture — why it beats keyword matching
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
            {[
              { label: "Career Function", pct: "40%", desc: "What did they actually DO at work? Title + description parsing to detect functional domain. Keyword stuffers ranked low even with perfect skills list." },
              { label: "Skills Depth", pct: "25%", desc: "Proficiency × duration × endorsements. Expert skill with 0 months = red flag. Only retrieval/embedding/ML core skills count." },
              { label: "Experience Fit", pct: "15%", desc: "JD wants 5–9 years. Soft bands: score peaks at 5–9y, declines for under/over." },
              { label: "Education", pct: "10%", desc: "Tier 1 (IIT/IISc/global) bonus, CS/ML field bonus. Not a hard filter — career evidence wins." },
              { label: "Activity Signals", pct: "10%", desc: "GitHub activity score + profile completeness + relevant certifications." },
              { label: "Availability ×", pct: "multiplier", desc: "Deterministic post-score: days inactive, open_to_work, recruiter response rate, interview completion rate." },
            ].map((item) => (
              <div key={item.label} className="flex gap-3 p-3 rounded bg-secondary/40 border border-border/50">
                <div className="text-right shrink-0">
                  <span className="text-xs font-mono font-bold text-primary">{item.pct}</span>
                </div>
                <div>
                  <p className="font-medium text-sm">{item.label}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Action buttons */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1 border border-border rounded-lg p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">Demo Mode</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Rank the 50-candidate sample — instant, shows the approach</p>
            </div>
            <Badge variant="secondary">~1s</Badge>
          </div>
          <Button
            className="w-full"
            variant="outline"
            onClick={() => run(true)}
            disabled={loading}
          >
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Cpu className="mr-2 h-4 w-4" />}
            Run Demo Ranker (50 candidates)
          </Button>
        </div>

        <div className="flex-1 border border-primary/40 rounded-lg p-5 space-y-3 bg-primary/5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">Full Submission</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Rank all 100,000 candidates — produces the actual challenge CSV</p>
            </div>
            <Badge className="bg-primary/20 text-primary border-primary/30">~2 min</Badge>
          </div>
          <Button
            className="w-full"
            onClick={() => run(false)}
            disabled={loading}
          >
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trophy className="mr-2 h-4 w-4" />}
            Generate Full Submission (100k)
          </Button>
        </div>
      </div>

      {/* Loading state */}
      {loading && (
        <Card>
          <CardContent className="p-8 text-center space-y-4">
            <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto" />
            <div>
              <h3 className="font-semibold">Ranking in Progress</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Streaming JSONL · scoring career function · detecting honeypots · no API calls
              </p>
            </div>
            <div className="max-w-xs mx-auto space-y-1.5">
              {[0.7, 0.45, 0.85].map((w, i) => (
                <div key={i} className="h-1 w-full bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-primary animate-pulse" style={{ width: `${w * 100}%` }} />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Error */}
      {error && (
        <Card className="border-destructive/50">
          <CardContent className="p-4 flex gap-3 text-sm text-destructive">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </CardContent>
        </Card>
      )}

      {/* Results */}
      {result && (
        <div className="space-y-5">
          {/* Stats bar */}
          <div className="flex flex-wrap items-center gap-4 p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <div className="flex flex-wrap gap-6 text-sm">
              <span><span className="text-muted-foreground">Processed:</span> <strong>{result.stats.totalProcessed.toLocaleString()} candidates</strong></span>
              {result.stats.elapsed != null && (
                <span><span className="text-muted-foreground">Time:</span> <strong>{result.stats.elapsed}s</strong></span>
              )}
              {result.stats.honeypotCount != null && result.stats.honeypotCount > 0 && (
                <span><span className="text-muted-foreground">Honeypots detected:</span> <strong className="text-amber-400">{result.stats.honeypotCount}</strong></span>
              )}
              {result.stats.topCandidate && (
                <span><span className="text-muted-foreground">Top score:</span> <strong>{result.stats.topCandidate.score.toFixed(4)}</strong></span>
              )}
              <span>
                <Badge variant={result.mode === "full" ? "default" : "secondary"}>
                  {result.mode === "full" ? "Full submission" : "Demo / sample"}
                </Badge>
              </span>
            </div>

            <Button
              className="ml-auto"
              onClick={() => downloadCsv(result.csv, result.mode === "full" ? "team_submission.csv" : "team_demo_submission.csv")}
            >
              <Download className="mr-2 h-4 w-4" />
              Download CSV
            </Button>
          </div>

          {/* Preview table */}
          <div className="border border-border rounded-lg overflow-hidden">
            <div className="px-4 py-3 bg-secondary/30 border-b border-border flex items-center justify-between">
              <h3 className="text-sm font-semibold">
                {result.mode === "full" ? "Top 10 Preview (full ranking)" : `All ${result.rows.length} ranked candidates`}
              </h3>
              {result.mode === "full" && (
                <span className="text-xs text-muted-foreground">Download CSV for full top 100</span>
              )}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-border bg-secondary/20">
                    <th className="text-left px-4 py-2.5 font-semibold text-muted-foreground w-12">Rank</th>
                    <th className="text-left px-4 py-2.5 font-semibold text-muted-foreground w-32">Candidate ID</th>
                    <th className="text-left px-4 py-2.5 font-semibold text-muted-foreground w-20">Score</th>
                    <th className="text-left px-4 py-2.5 font-semibold text-muted-foreground">Reasoning</th>
                  </tr>
                </thead>
                <tbody>
                  {displayRows.map((row) => (
                    <tr key={row.candidate_id} className="border-b border-border/50 hover:bg-secondary/20">
                      <td className="px-4 py-2.5">
                        <span className={`font-mono font-bold ${row.rank <= 10 ? "text-primary" : "text-muted-foreground"}`}>
                          #{row.rank}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 font-mono text-muted-foreground">{row.candidate_id}</td>
                      <td className="px-4 py-2.5">
                        <div className="flex items-center gap-1.5">
                          <div className="h-1 w-12 bg-secondary rounded-full overflow-hidden">
                            <div className="h-full bg-primary rounded-full" style={{ width: `${row.score * 100}%` }} />
                          </div>
                          <span className="font-mono">{row.score.toFixed(4)}</span>
                        </div>
                      </td>
                      <td className="px-4 py-2.5 text-muted-foreground max-w-xs truncate">{row.reasoning}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {result.rows.length > 10 && result.mode === "sample" && (
              <button
                onClick={() => setShowAll(!showAll)}
                className="w-full px-4 py-2.5 text-xs text-muted-foreground hover:text-foreground flex items-center justify-center gap-1 border-t border-border hover:bg-secondary/20 transition-colors"
              >
                {showAll ? <><ChevronUp className="w-3 h-3" /> Show less</> : <><ChevronDown className="w-3 h-3" /> Show all {result.rows.length} rows</>}
              </button>
            )}
          </div>

          {/* Submission checklist */}
          {result.mode === "full" && (
            <Card>
              <CardContent className="p-5 space-y-3">
                <h3 className="font-semibold text-sm">Submission Checklist</h3>
                <div className="space-y-2">
                  {[
                    { ok: true, label: "100 rows in CSV" },
                    { ok: true, label: "Ranks 1–100 each appear exactly once" },
                    { ok: true, label: "Scores non-increasing" },
                    { ok: true, label: "candidate_id tie-break: ascending (per spec §3)" },
                    { ok: true, label: "Reasoning column populated" },
                    { ok: true, label: "No OpenAI/Anthropic calls during ranking" },
                    { ok: null, label: "Validate locally: python validate_submission.py team_submission.csv" },
                    { ok: null, label: "Sandbox link: this Replit (Terminal Talent Intel)" },
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-2 text-sm">
                      {item.ok === true ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <div className="w-4 h-4 rounded border border-border shrink-0 mt-0.5" />
                      )}
                      <span className={item.ok ? "text-foreground" : "text-muted-foreground"}>{item.label}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
