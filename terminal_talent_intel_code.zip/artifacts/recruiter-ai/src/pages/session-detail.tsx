import React, { useState } from "react";
import { useGetRankingSession, useExportRankingSession, getGetRankingSessionQueryKey } from "@workspace/api-client-react";
import { useParams, Link } from "wouter";
import { RankedCandidateCard } from "./rank";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Download, Users, Calendar } from "lucide-react";
import { format } from "date-fns";

export function SessionDetail() {
  const params = useParams();
  const id = parseInt(params.id || "0", 10);
  
  const { data: session, isLoading } = useGetRankingSession(id, {
    query: { enabled: !!id, queryKey: getGetRankingSessionQueryKey(id) }
  });

  const [exporting, setExporting] = useState(false);
  const { refetch: fetchExport } = useExportRankingSession(id, {
    query: { enabled: false, queryKey: getGetRankingSessionQueryKey(id) }
  });

  const handleExport = async () => {
    setExporting(true);
    try {
      const result = await fetchExport();
      if (result.data) {
        const blob = new Blob([result.data as string], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `ranking-session-${id}.csv`;
        a.click();
        window.URL.revokeObjectURL(url);
      }
    } finally {
      setExporting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-8 max-w-5xl mx-auto space-y-6">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-20 w-full" />
        <div className="space-y-4">
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  if (!session) {
    return <div className="p-8">Session not found.</div>;
  }

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-8">
      <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
        <Link href="/" className="hover:text-foreground flex items-center gap-1 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to Dashboard
        </Link>
      </div>

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-border pb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2">{session.jobTitle}</h1>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              {format(new Date(session.createdAt), "MMM d, yyyy")}
            </span>
            <span className="flex items-center gap-1">
              <Users className="w-4 h-4" />
              {session.rankedCandidates.length} matches
            </span>
          </div>
        </div>
        <Button onClick={handleExport} disabled={exporting} variant="outline" className="gap-2">
          <Download className="w-4 h-4" />
          {exporting ? "Exporting..." : "Export CSV"}
        </Button>
      </div>

      {session.jobDescription && (
        <div className="bg-secondary/20 border border-border p-4 rounded-lg text-sm text-muted-foreground font-mono max-h-32 overflow-y-auto">
          {session.jobDescription}
        </div>
      )}

      <div className="space-y-4">
        <h2 className="text-xl font-semibold mb-4">Ranked Candidates</h2>
        {session.rankedCandidates.map((candidate, idx) => (
          <RankedCandidateCard key={candidate.candidateId} candidate={candidate} rank={idx + 1} />
        ))}
        {session.rankedCandidates.length === 0 && (
          <div className="text-center p-12 bg-card border border-border rounded-lg text-muted-foreground">
            No candidates were ranked in this session.
          </div>
        )}
      </div>
    </div>
  );
}
