import React, { useState } from "react";
import { useListCandidates, useGetCandidate, getListCandidatesQueryKey, getGetCandidateQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Search, MapPin, Briefcase, ChevronRight, X, Clock, BadgeCheck, Github, GraduationCap, Building2, Globe, MonitorSmartphone, Home, Star } from "lucide-react";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription } from "@/components/ui/drawer";
import { useDebounce } from "@/hooks/use-debounce";

const PROFICIENCY_COLORS: Record<string, string> = {
  expert: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
  advanced: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  intermediate: "bg-yellow-500/20 text-yellow-500 border-yellow-500/30",
  beginner: "bg-zinc-500/20 text-zinc-400 border-zinc-500/30",
};

const WORK_MODE_ICONS: Record<string, React.ReactNode> = {
  remote: <Globe className="w-3 h-3" />,
  hybrid: <MonitorSmartphone className="w-3 h-3" />,
  onsite: <Building2 className="w-3 h-3" />,
  flexible: <Home className="w-3 h-3" />,
};

function SkillPills({ skills }: { skills: Array<{ name: string; proficiency: string }> | null | undefined }) {
  if (!skills || skills.length === 0) return <span className="text-xs text-muted-foreground">No skills listed</span>;
  const sorted = [...skills].sort((a, b) => {
    const order = ["expert", "advanced", "intermediate", "beginner"];
    return order.indexOf(a.proficiency) - order.indexOf(b.proficiency);
  });
  return (
    <div className="flex flex-wrap gap-1">
      {sorted.map((s) => (
        <span key={s.name} className={`px-1.5 py-0.5 rounded text-[10px] border font-medium ${PROFICIENCY_COLORS[s.proficiency] ?? PROFICIENCY_COLORS.beginner}`}>
          {s.name}
        </span>
      ))}
    </div>
  );
}

function CandidateDrawer({ candidateId, onClose }: { candidateId: number | null; onClose: () => void }) {
  const { data: c, isLoading } = useGetCandidate(candidateId || 0, {
    query: { enabled: !!candidateId, queryKey: getGetCandidateQueryKey(candidateId || 0) }
  });
  const career = (c?.careerHistory as any[]) || [];
  const education = (c?.education as any[]) || [];
  const skills = (c?.skills as any[]) || [];
  const certs = (c?.certifications as any[]) || [];

  return (
    <Drawer open={!!candidateId} onOpenChange={(open) => !open && onClose()}>
      <DrawerContent className="max-h-[92vh]">
        {isLoading ? (
          <div className="mx-auto w-full max-w-5xl p-6 space-y-4">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-5 w-48" />
            <div className="grid grid-cols-3 gap-8 mt-6">
              <div className="col-span-2 space-y-4">
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-40 w-full" />
              </div>
              <div className="space-y-4">
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
              </div>
            </div>
          </div>
        ) : c ? (
          <div className="mx-auto w-full max-w-5xl flex flex-col h-full">
            <DrawerHeader className="border-b border-border pb-4 shrink-0">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3 flex-wrap">
                    <DrawerTitle className="text-xl">{c.name}</DrawerTitle>
                    {c.openToWork && (
                      <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/25">
                        <BadgeCheck className="w-3.5 h-3.5" /> Open to Work
                      </span>
                    )}
                    {c.candidateId && <span className="text-xs font-mono text-muted-foreground/50">{c.candidateId}</span>}
                  </div>
                  <DrawerDescription className="mt-1">
                    {c.currentTitle} · {c.currentCompany}
                    {c.currentCompanySize && <span className="text-xs opacity-60"> ({c.currentCompanySize})</span>}
                  </DrawerDescription>
                  <div className="flex flex-wrap gap-3 text-xs text-muted-foreground mt-2">
                    {c.location && <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{c.location}, {c.country}</span>}
                    {c.yearsExperience != null && <span className="flex items-center gap-1"><Briefcase className="w-3.5 h-3.5" />{c.yearsExperience} yrs exp</span>}
                    {c.currentIndustry && <span>{c.currentIndustry}</span>}
                  </div>
                </div>

                {/* Key signals grid */}
                <div className="hidden md:grid grid-cols-2 gap-2 text-xs shrink-0">
                  {c.noticePeriodDays != null && (
                    <div className="flex items-center gap-1.5 px-3 py-2 rounded bg-secondary/50 border border-border">
                      <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                      <div>
                        <div className="text-[10px] text-muted-foreground">Notice</div>
                        <div className="font-semibold">{c.noticePeriodDays === 0 ? "Immediate" : `${c.noticePeriodDays}d`}</div>
                      </div>
                    </div>
                  )}
                  {c.expectedSalaryMin != null && (
                    <div className="px-3 py-2 rounded bg-secondary/50 border border-border">
                      <div className="text-[10px] text-muted-foreground">Expected CTC</div>
                      <div className="font-semibold">₹{c.expectedSalaryMin}–{c.expectedSalaryMax} LPA</div>
                    </div>
                  )}
                  {c.preferredWorkMode && (
                    <div className="flex items-center gap-1.5 px-3 py-2 rounded bg-secondary/50 border border-border capitalize">
                      {WORK_MODE_ICONS[c.preferredWorkMode]}
                      <div>
                        <div className="text-[10px] text-muted-foreground">Work Mode</div>
                        <div className="font-semibold">{c.preferredWorkMode}</div>
                      </div>
                    </div>
                  )}
                  {c.githubActivityScore != null && c.githubActivityScore >= 0 && (
                    <div className="flex items-center gap-1.5 px-3 py-2 rounded bg-secondary/50 border border-border">
                      <Github className="w-3.5 h-3.5 text-muted-foreground" />
                      <div>
                        <div className="text-[10px] text-muted-foreground">GitHub</div>
                        <div className="font-semibold">{c.githubActivityScore.toFixed(0)}/100</div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </DrawerHeader>

            <div className="overflow-y-auto p-6 flex-1">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {/* Main column */}
                <div className="md:col-span-2 space-y-6">
                  {c.summary && (
                    <section>
                      <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Summary</h4>
                      <p className="text-sm leading-relaxed">{c.summary}</p>
                    </section>
                  )}

                  {career.length > 0 && (
                    <section>
                      <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Career History</h4>
                      <div className="space-y-4">
                        {career.map((role: any, i: number) => (
                          <div key={i} className="relative pl-4 border-l-2 border-border">
                            <div className="absolute -left-1.5 top-1.5 w-2.5 h-2.5 rounded-full bg-primary/40 border border-primary" />
                            <div className="flex items-start justify-between gap-2">
                              <div>
                                <p className="font-semibold text-sm">{role.title}</p>
                                <p className="text-xs text-muted-foreground">{role.company} · {role.company_size} · {role.industry}</p>
                              </div>
                              <span className="text-[10px] text-muted-foreground shrink-0 font-mono">
                                {role.start_date} – {role.is_current ? "Present" : role.end_date} ({role.duration_months}mo)
                              </span>
                            </div>
                            {role.description && (
                              <p className="mt-1.5 text-xs text-muted-foreground leading-relaxed">{role.description}</p>
                            )}
                          </div>
                        ))}
                      </div>
                    </section>
                  )}

                  {education.length > 0 && (
                    <section>
                      <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Education</h4>
                      <div className="space-y-2">
                        {education.map((e: any, i: number) => (
                          <div key={i} className="flex items-start gap-3 p-3 rounded bg-secondary/30 border border-border/50">
                            <GraduationCap className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" />
                            <div>
                              <p className="text-sm font-medium">
                                {e.institution}
                                {e.tier === "tier_1" && <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400 border border-amber-500/25 font-semibold">Tier 1</span>}
                                {e.tier === "tier_2" && <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded bg-blue-500/15 text-blue-400 border border-blue-500/25 font-semibold">Tier 2</span>}
                              </p>
                              <p className="text-xs text-muted-foreground">{e.degree} · {e.field_of_study} · {e.start_year}–{e.end_year}</p>
                              {e.grade && <p className="text-xs text-muted-foreground/70 mt-0.5">{e.grade}</p>}
                            </div>
                          </div>
                        ))}
                      </div>
                    </section>
                  )}
                </div>

                {/* Sidebar */}
                <div className="space-y-6">
                  <section>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Skills</h4>
                    <SkillPills skills={skills} />
                  </section>

                  {certs.length > 0 && (
                    <section>
                      <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Certifications</h4>
                      <div className="space-y-1.5">
                        {certs.map((cert: any, i: number) => (
                          <div key={i} className="flex items-start gap-2 text-xs">
                            <Star className="w-3 h-3 text-amber-400 shrink-0 mt-0.5" />
                            <div>
                              <p className="font-medium">{cert.name}</p>
                              <p className="text-muted-foreground">{cert.issuer} · {cert.year}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </section>
                  )}

                  <section>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Availability Signals</h4>
                    <div className="space-y-2 text-xs">
                      {[
                        { label: "Recruiter Response", value: c.recruiterResponseRate != null ? `${Math.round(c.recruiterResponseRate * 100)}%` : null, warn: c.recruiterResponseRate != null && c.recruiterResponseRate < 0.3 },
                        { label: "Interview Completion", value: c.interviewCompletionRate != null ? `${Math.round(c.interviewCompletionRate * 100)}%` : null, warn: c.interviewCompletionRate != null && c.interviewCompletionRate < 0.5 },
                        { label: "Last Active", value: c.lastActiveDate ?? null, warn: false },
                        { label: "Willing to Relocate", value: c.willingToRelocate ? "Yes" : "No", warn: false },
                      ].map(({ label, value, warn }) => value != null && (
                        <div key={label} className="flex justify-between">
                          <span className="text-muted-foreground">{label}</span>
                          <span className={warn ? "text-amber-400 font-medium" : "font-medium"}>{value}</span>
                        </div>
                      ))}
                    </div>
                  </section>
                </div>
              </div>
            </div>
          </div>
        ) : null}
      </DrawerContent>
    </Drawer>
  );
}

export function Candidates() {
  const [searchTerm, setSearchTerm] = useState("");
  const debouncedSearch = useDebounce(searchTerm, 500);
  const [selectedCandidateId, setSelectedCandidateId] = useState<number | null>(null);

  const { data: candidates, isLoading } = useListCandidates(
    { skills: debouncedSearch || undefined },
    { query: { queryKey: getListCandidatesQueryKey({ skills: debouncedSearch || undefined }) } }
  );

  return (
    <div className="p-8 max-w-7xl mx-auto flex flex-col h-[calc(100vh-2rem)]">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6 shrink-0">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Candidate Pool</h1>
          <p className="text-muted-foreground mt-1">
            {candidates ? `${candidates.length} candidates` : "Loading..."} · Click any row to view full profile
          </p>
        </div>
        <div className="relative w-full md:w-72">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search by skill..." className="pl-9" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
          {searchTerm && (
            <button onClick={() => setSearchTerm("")} className="absolute right-2.5 top-2.5 text-muted-foreground hover:text-foreground">
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pr-1 space-y-2">
        {isLoading ? (
          Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)
        ) : candidates?.length ? (
          candidates.map((candidate) => {
            const skills = candidate.skills as Array<{ name: string; proficiency: string }> | null;
            const topSkills = skills?.filter(s => s.proficiency === "expert" || s.proficiency === "advanced").slice(0, 3) ?? [];
            return (
              <Card
                key={candidate.id}
                className="cursor-pointer hover:border-primary/50 transition-colors group"
                onClick={() => setSelectedCandidateId(candidate.id)}
              >
                <CardContent className="p-4 flex items-center gap-4">
                  {/* Identity */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <h3 className="font-semibold text-sm group-hover:text-primary transition-colors truncate">{candidate.name}</h3>
                      {candidate.openToWork && (
                        <span className="shrink-0 flex items-center gap-0.5 text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/25 font-semibold">
                          <BadgeCheck className="w-2.5 h-2.5" /> Open
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground truncate">
                      {candidate.currentTitle}{candidate.currentCompany ? ` · ${candidate.currentCompany}` : ""}
                    </p>
                    <div className="flex items-center gap-3 mt-1 text-[11px] text-muted-foreground">
                      {candidate.location && <span className="flex items-center gap-1"><MapPin className="w-2.5 h-2.5" />{candidate.location}</span>}
                      {candidate.yearsExperience != null && <span className="flex items-center gap-1"><Briefcase className="w-2.5 h-2.5" />{candidate.yearsExperience}y</span>}
                    </div>
                  </div>

                  {/* Top skills */}
                  <div className="hidden md:flex flex-wrap gap-1 max-w-[180px] justify-end">
                    {topSkills.map(s => (
                      <span key={s.name} className={`px-1.5 py-0.5 rounded text-[10px] border font-medium ${PROFICIENCY_COLORS[s.proficiency]}`}>
                        {s.name}
                      </span>
                    ))}
                    {skills && skills.length > topSkills.length && (
                      <span className="text-[10px] text-muted-foreground self-center">+{skills.length - topSkills.length}</span>
                    )}
                  </div>

                  {/* Quick stats */}
                  <div className="hidden lg:flex items-center gap-3 text-[11px] text-muted-foreground shrink-0">
                    {candidate.noticePeriodDays != null && (
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />{candidate.noticePeriodDays === 0 ? "Immediate" : `${candidate.noticePeriodDays}d`}
                      </span>
                    )}
                    {candidate.preferredWorkMode && (
                      <span className="flex items-center gap-1 capitalize">
                        {WORK_MODE_ICONS[candidate.preferredWorkMode]}{candidate.preferredWorkMode}
                      </span>
                    )}
                  </div>

                  <ChevronRight className="w-4 h-4 text-muted-foreground/40 group-hover:text-primary shrink-0" />
                </CardContent>
              </Card>
            );
          })
        ) : (
          <div className="text-center p-12 border-2 border-dashed border-border rounded-lg text-muted-foreground">
            <Search className="w-10 h-10 mx-auto mb-4 opacity-20" />
            <h3 className="font-medium text-foreground">No candidates found</h3>
            <p className="text-sm mt-1">Try a different skill search.</p>
          </div>
        )}
      </div>

      <CandidateDrawer candidateId={selectedCandidateId} onClose={() => setSelectedCandidateId(null)} />
    </div>
  );
}
