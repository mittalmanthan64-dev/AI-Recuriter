#!/usr/bin/env python3
"""
Redrob Hackathon — CPU-only candidate ranker.
No external API calls. Runs in <5 minutes on 100k candidates.

Usage:
    python rank_candidates.py --candidates ./candidates.jsonl --out ./team_submission.csv
    python rank_candidates.py --candidates ./candidates.json  --out ./team_submission.csv  # JSON array also supported
    python rank_candidates.py --sample  # rank bundled 50-candidate sample

Compute constraints: CPU only, no network, <5 min, <16 GB RAM.
"""

import argparse
import csv
import gzip
import json
import sys
import time
from pathlib import Path

# ─── JD Signal Keywords ───────────────────────────────────────────────────────
# Senior AI Engineer @ Redrob AI — embeddings + retrieval + ranking focus

AI_ML_TITLE_KWS = [
    "machine learning", "ml engineer", "ml scientist", "ai engineer",
    "data scientist", "research scientist", "applied scientist", "applied ml",
    "nlp engineer", "nlp scientist", "computer vision", "deep learning engineer",
    "recommendation", "ranking engineer", "search engineer", "retrieval",
    "intelligence engineer", "algorithm engineer", "ml lead", "ai lead",
    "ml platform", "ai platform", "principal ml", "senior ml", "staff ml",
    "mlops engineer", "applied research", "ai researcher",
]

SOFTWARE_ADJACENT_KWS = [
    "software engineer", "software developer", "backend engineer", "full stack",
    "platform engineer", "data engineer", "devops engineer", "site reliability",
    "sre", "cloud engineer", "infrastructure engineer", "solutions architect",
    "backend developer", "full-stack", "tech lead", "engineering manager",
]

NON_TECH_KWS = [
    "marketing", "sales executive", "sales manager", "hr ", "human resource",
    "graphic design", "content writer", "content manager", "seo ", "copywriter",
    "accountant", "accounting", "finance manager", "civil engineer",
    "mechanical engineer", "customer support", "customer success",
    "operations manager", "project manager", "business analyst",
    "supply chain", "procurement", "logistics", "construction",
    "manufacturing", "ux designer", "ui designer", "product designer",
    "social media", "digital marketing", "brand manager",
]

DESC_HIGH_VALUE = [
    "embedding", "vector", "retrieval", "semantic search", "ranking",
    "recommendation", "reranking", "re-ranking", "re-rank",
    "llm", "large language model", "transformer", "bert", "gpt",
    "similarity search", "approximate nearest neighbor", "ann",
    "faiss", "pinecone", "weaviate", "qdrant", "milvus", "opensearch",
    "model training", "model serving", "model deployment", "inference",
    "fine-tun", "rlhf", "instruction tuning", "pretrain",
    "ndcg", "mrr", "map@", "precision@", "recall@",
    "production ml", "ml pipeline", "feature engineering at scale",
    "sentence-transformer", "bi-encoder", "cross-encoder",
    "dense retrieval", "hybrid search", "bm25",
    "neural search", "vector database", "vector store",
]

DESC_MED_VALUE = [
    "machine learning", "deep learning", "neural network",
    "natural language", "nlp", "computer vision", "pytorch", "tensorflow",
    "scikit-learn", "hugging face", "huggingface", "langchain", "llamaindex",
    "classification", "regression", "clustering", "feature selection",
    "data pipeline", "etl", "spark", "kafka",
    "a/b test", "experiment", "metric", "evaluation framework",
]

RETRIEVAL_SKILLS = {
    "embeddings", "vector search", "faiss", "pinecone", "weaviate", "qdrant",
    "milvus", "chroma", "elasticsearch", "opensearch", "semantic search",
    "rag", "retrieval augmented generation", "retrieval", "reranking",
    "re-ranking", "bi-encoder", "cross-encoder", "dense retrieval",
    "hybrid search", "sentence-transformers", "sentence transformers",
    "bge", "e5 embeddings", "ada embeddings", "openai embeddings",
    "recommendation systems", "recommender", "collaborative filtering",
    "learning to rank", "ltr", "ranking", "vector database", "vector store",
    "approximate nearest neighbor", "ann", "similarity search",
}

ML_CORE_SKILLS = {
    "machine learning", "deep learning", "pytorch", "tensorflow", "jax",
    "nlp", "natural language processing", "transformers", "bert",
    "llm", "large language models", "scikit-learn", "sklearn",
    "python", "mlflow", "kubeflow", "sagemaker", "hugging face", "huggingface",
    "langchain", "llamaindex", "fine-tuning", "rlhf", "computer vision",
    "feature engineering", "model serving", "triton", "onnx",
    "data pipelines", "apache spark", "airflow",
}


def proficiency_weight(p):
    return {"expert": 1.0, "advanced": 0.75, "intermediate": 0.40, "beginner": 0.08}.get(p, 0.05)


def duration_multiplier(months):
    if months == 0:   return 0.05
    if months < 3:    return 0.15
    if months < 6:    return 0.35
    if months < 12:   return 0.60
    if months < 24:   return 0.85
    return 1.0


def is_retrieval_skill(name):
    n = name.lower()
    return n in RETRIEVAL_SKILLS or any(kw in n for kw in RETRIEVAL_SKILLS)


def is_ml_core_skill(name):
    n = name.lower()
    return n in ML_CORE_SKILLS or any(kw in n for kw in ML_CORE_SKILLS)


# ─── Honeypot Detection ───────────────────────────────────────────────────────
def detect_honeypot(c):
    skills = c.get("skills", [])

    # Expert skills with 0 months duration
    expert_zero = sum(1 for s in skills if s.get("proficiency") == "expert" and s.get("duration_months", 1) == 0)
    if expert_zero >= 4:
        return True

    # All skills "expert" with 10+ skills
    if len(skills) >= 8 and all(s.get("proficiency") == "expert" for s in skills):
        return True

    # YoE >> career history total
    yoe = c.get("profile", {}).get("years_of_experience", 0) or 0
    career = c.get("career_history", []) or []
    total_months = sum(r.get("duration_months", 0) or 0 for r in career)
    if yoe >= 3 and total_months > 0:
        implied_years = total_months / 12
        if implied_years < yoe * 0.25 and yoe - implied_years > 6:
            return True

    # Many advanced/expert skills with 0 months
    adv_zero = sum(
        1 for s in skills
        if s.get("proficiency") in ("advanced", "expert") and s.get("duration_months", 1) == 0
    )
    if adv_zero >= 7:
        return True

    return False


# ─── Scoring Components ───────────────────────────────────────────────────────
def score_title(title):
    t = title.lower()
    if any(kw in t for kw in AI_ML_TITLE_KWS):     return 95
    if any(kw in t for kw in SOFTWARE_ADJACENT_KWS): return 45
    if any(kw in t for kw in NON_TECH_KWS):          return 5
    return 25


def score_description(desc):
    if not desc or len(desc) < 20:
        return 15
    d = desc.lower()
    high = sum(1 for kw in DESC_HIGH_VALUE if kw in d)
    med  = sum(1 for kw in DESC_MED_VALUE  if kw in d)
    return min(100, max(5, high * 18 + med * 6))


def compute_career_score(c):
    career = c.get("career_history") or []
    current_title = (c.get("profile") or {}).get("current_title", "") or ""

    if not career:
        return score_title(current_title) * 0.5

    weighted = 0.0
    total_w  = 0.0
    for role in career:
        ts = score_title(role.get("title", "") or "")
        ds = score_description(role.get("description", "") or "")
        rs = ts * 0.6 + ds * 0.4
        recency_w = 3.0 if role.get("is_current") else 1.5
        dur_w     = max(1, role.get("duration_months", 1) or 1)
        weighted += rs * recency_w * dur_w
        total_w  += recency_w * dur_w

    hist = weighted / total_w if total_w else 20
    title_boost = score_title(current_title)
    return hist * 0.7 + title_boost * 0.3


def compute_skills_score(c):
    skills = c.get("skills") or []
    retrieval_pts = 0.0
    ml_pts = 0.0
    for sk in skills:
        name = (sk.get("name") or "").lower()
        p    = proficiency_weight(sk.get("proficiency", "beginner"))
        d    = duration_multiplier(sk.get("duration_months", 0) or 0)
        e    = min(0.25, (sk.get("endorsements", 0) or 0) * 0.025)
        wt   = p * d + e
        if is_retrieval_skill(name):
            retrieval_pts += wt * 2.5
        elif is_ml_core_skill(name):
            ml_pts += wt
    return min(100, retrieval_pts * 20 + ml_pts * 7)


def compute_exp_score(c):
    yoe = (c.get("profile") or {}).get("years_of_experience", 0) or 0
    if 5 <= yoe <= 9:    return 100
    if yoe in (4, 10):   return 85
    if yoe == 3 or 11 <= yoe <= 12: return 65
    if yoe == 2 or 13 <= yoe <= 15: return 45
    if yoe >= 16:         return 30
    return 20


def compute_edu_score(c):
    edu = c.get("education") or []
    if not edu:
        return 30
    best = 30
    for e in edu:
        s = 30
        tier = e.get("tier", "tier_4") or "tier_4"
        s += {"tier_1": 35, "tier_2": 20, "tier_3": 10, "tier_4": 0}.get(tier, 0)
        field = (e.get("field_of_study") or "").lower()
        if any(kw in field for kw in ["computer", "software", "machine learning", "data science", "ai", "artificial intelligence", "nlp"]):
            s += 20
        elif any(kw in field for kw in ["math", "statistic", "electrical", "electronics"]):
            s += 12
        deg = (e.get("degree") or "").lower()
        if any(kw in deg for kw in ["ph.d", "phd", "doctor"]):  s += 10
        elif any(kw in deg for kw in ["m.tech", "m.s", "master"]): s += 8
        best = max(best, s)
    return min(100, best)


def compute_activity_score(c):
    sig   = c.get("redrob_signals") or {}
    score = 40.0
    gh    = sig.get("github_activity_score", -1)
    if gh >= 0:
        score += gh * 0.4
    score += (sig.get("profile_completeness_score", 50) or 50) * 0.15
    certs = c.get("certifications") or []
    ai_certs = sum(1 for cert in certs if any(kw in (cert.get("name") or "").lower()
        for kw in ["aws", "gcp", "azure", "tensorflow", "pytorch", "machine learning", "deep learning", "data science", "ai"]))
    score += min(10, ai_certs * 5)
    return min(100, score)


def compute_availability_multiplier(c):
    sig = c.get("redrob_signals") or {}
    m   = 1.0
    last = sig.get("last_active_date")
    if last:
        try:
            from datetime import datetime, timezone
            days = (datetime.now(timezone.utc) - datetime.fromisoformat(last.replace("Z", "+00:00"))).days
            if   days >= 180: m *= 0.55
            elif days >= 90:  m *= 0.75
            elif days >= 45:  m *= 0.88
        except Exception:
            pass
    if not sig.get("open_to_work_flag", True):
        m *= 0.90
    rrr = sig.get("recruiter_response_rate", 1.0) or 1.0
    if   rrr < 0.10: m *= 0.80
    elif rrr < 0.25: m *= 0.92
    icr = sig.get("interview_completion_rate", 1.0) or 1.0
    if   icr < 0.30: m *= 0.82
    elif icr < 0.50: m *= 0.93
    art = sig.get("avg_response_time_hours", 0) or 0
    if art > 168:
        m *= 0.90
    return max(0.12, m)


def score_candidate(c):
    if detect_honeypot(c):
        return 0.0, True

    career_s   = compute_career_score(c)
    skills_s   = compute_skills_score(c)
    exp_s      = compute_exp_score(c)
    edu_s      = compute_edu_score(c)
    activity_s = compute_activity_score(c)

    raw = career_s * 0.40 + skills_s * 0.25 + exp_s * 0.15 + edu_s * 0.10 + activity_s * 0.10
    mult = compute_availability_multiplier(c)
    return (raw / 100.0) * mult, False


def generate_reasoning(c, rank):
    p   = c.get("profile", {}) or {}
    sig = c.get("redrob_signals", {}) or {}
    skills = c.get("skills") or []
    career = c.get("career_history") or []

    top_skills = sorted(
        [s for s in skills if s.get("proficiency") in ("expert", "advanced") and (s.get("duration_months") or 0) >= 6],
        key=lambda s: proficiency_weight(s.get("proficiency", "beginner")) * (s.get("duration_months") or 0),
        reverse=True,
    )[:3]
    skill_str = "; ".join(f"{s['name']} ({s['proficiency']}, {s['duration_months']}mo)" for s in top_skills)

    ai_roles = [r for r in career if any(kw in (r.get("title") or "").lower() for kw in AI_ML_TITLE_KWS)]
    top_role = (ai_roles or career or [None])[0]

    notice_d = sig.get("notice_period_days", 60) or 60
    notice_str = "immediate availability" if notice_d == 0 else f"{notice_d}d notice"
    status_str = "actively looking" if sig.get("open_to_work_flag") else "passive"

    last = sig.get("last_active_date")
    days_inactive = None
    if last:
        try:
            from datetime import datetime, timezone
            days_inactive = (datetime.now(timezone.utc) - datetime.fromisoformat(last.replace("Z", "+00:00"))).days
        except Exception:
            pass
    avail_note = f"; inactive {days_inactive}d (availability penalty applied)" if days_inactive and days_inactive >= 45 else ""

    title   = p.get("current_title", "Engineer") or "Engineer"
    company = p.get("current_company", "") or ""
    yoe     = p.get("years_of_experience", 0) or 0

    if rank <= 15:
        role_desc = f"{top_role['duration_months']}mo at {top_role['company']} as {top_role['title']}" if top_role else f"{yoe}y experience"
        return f"{title} at {company} with {yoe}y exp; {role_desc}; skills: {skill_str or 'undisclosed'}; {status_str}, {notice_str}{avail_note}."
    elif rank <= 40:
        career_score_approx = compute_career_score(c)
        gap = ("career history primarily in non-ML domains" if career_score_approx < 50
               else "limited retrieval/embedding production evidence")
        return f"{title} with {yoe}y exp; {gap}; {status_str}, {notice_str}{avail_note}."
    else:
        return f"Career function mismatch or insufficient retrieval evidence; {yoe}y tenure; {status_str}{avail_note}."


def load_candidates(path_str):
    path = Path(path_str)
    if not path.exists():
        raise FileNotFoundError(f"Not found: {path}")

    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    yield json.loads(line)
    elif path.suffix == ".jsonl":
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    yield json.loads(line)
    elif path.suffix == ".json":
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                yield from data
            else:
                yield data
    else:
        raise ValueError(f"Unsupported file format: {path.suffix}")


def rank_all(candidates_path, top_n=100):
    KEEP_TOP = 1000
    heap = []   # (score, candidate_id, candidate)
    honeypot_count = 0
    processed = 0
    t0 = time.time()

    for c in load_candidates(candidates_path):
        score, is_honeypot = score_candidate(c)
        if is_honeypot:
            honeypot_count += 1
        candidate_id = c.get("candidate_id", "")

        if len(heap) < KEEP_TOP or score > heap[0][0]:
            heap.append((score, candidate_id, c))
            if len(heap) > KEEP_TOP:
                heap.sort(key=lambda x: x[0], reverse=True)
                heap = heap[:KEEP_TOP]

        processed += 1
        if processed % 10000 == 0:
            elapsed = time.time() - t0
            print(f"  {processed:,} candidates processed ({elapsed:.1f}s)...", file=sys.stderr)

    heap.sort(key=lambda x: (-x[0], x[1]))  # score desc, id asc for tie-breaking
    top = heap[:top_n]

    rows = []
    for rank_idx, (score, cid, c) in enumerate(top, start=1):
        normalized = min(0.9999, max(0.0001, score))
        reasoning = generate_reasoning(c, rank_idx)
        rows.append({
            "candidate_id": cid,
            "rank": rank_idx,
            "score": f"{normalized:.4f}",
            "reasoning": reasoning,
            "_raw_score": normalized,
        })

    # Re-sort after rounding to enforce tie-break: score desc, candidate_id asc (spec §3)
    rows.sort(key=lambda r: (-float(r["score"]), r["candidate_id"]))
    for i, row in enumerate(rows, start=1):
        row["rank"] = i

    # Ensure non-increasing scores (clamp)
    for i in range(1, len(rows)):
        if float(rows[i]["score"]) > float(rows[i-1]["score"]):
            rows[i]["score"] = rows[i-1]["score"]

    # Remove internal key
    for r in rows:
        r.pop("_raw_score", None)

    elapsed = time.time() - t0
    print(f"✓ Ranked {processed:,} candidates in {elapsed:.1f}s. Honeypots detected: {honeypot_count}.", file=sys.stderr)
    return rows


def write_csv(rows, out_path):
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["candidate_id", "rank", "score", "reasoning"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"✓ Written: {out_path} ({len(rows)} rows)", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser(description="Redrob Hackathon — CPU-only candidate ranker")
    parser.add_argument("--candidates", "-c", default=None, help="Path to candidates.jsonl, .jsonl.gz, or .json")
    parser.add_argument("--out", "-o", default="team_submission.csv", help="Output CSV path")
    parser.add_argument("--top-n", type=int, default=100, help="Number of candidates to rank (default: 100)")
    parser.add_argument("--sample", action="store_true", help="Use the bundled 50-candidate sample")
    args = parser.parse_args()

    if args.sample:
        # Use the bundled sample
        script_dir = Path(__file__).parent
        candidates_path = script_dir / "artifacts" / "api-server" / "data" / "candidates.json"
        if not candidates_path.exists():
            # Try relative path
            candidates_path = Path("artifacts/api-server/data/candidates.json")
        if not candidates_path.exists():
            print(f"Sample not found at {candidates_path}. Specify --candidates.", file=sys.stderr)
            sys.exit(1)
    elif args.candidates:
        candidates_path = args.candidates
    else:
        # Default to the full JSONL in the data directory
        script_dir = Path(__file__).parent
        candidates_path = script_dir / "artifacts" / "api-server" / "data" / "candidates.jsonl"
        if not candidates_path.exists():
            candidates_path = Path("artifacts/api-server/data/candidates.jsonl")
        if not candidates_path.exists():
            print("No candidate data found. Use --candidates <path> or --sample.", file=sys.stderr)
            sys.exit(1)

    print(f"Ranking from: {candidates_path}", file=sys.stderr)
    rows = rank_all(candidates_path, top_n=args.top_n)
    write_csv(rows, args.out)


if __name__ == "__main__":
    main()
